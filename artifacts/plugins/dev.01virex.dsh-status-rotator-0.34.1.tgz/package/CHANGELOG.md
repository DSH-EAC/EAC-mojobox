# 更新日志

本文件记录 dsh-status-rotator 的每个版本改了什么。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/),
版本号遵循[语义化版本](https://semver.org/lang/zh-CN/);安装与配置见 [README_ZH.md](./README_ZH.md)。

## [0.34.1] - 2026-10-02

### 修复

- **`appearance.fontSize: 0`(跟随宿主)被服务端夹成 8,保存后回退**(issue #129、#131):
  `0` 是 `config.example.json` 的出厂默认,浏览器半边**刻意放行**它,而服务端半边的合并段把它
  当成「小于下限 8」夹掉了 —— 于是设置页选 0 当场生效、服务端落盘 8、刷新 / 重连回退成 8px,
  而且**全程没有任何报错**,用户只会以为设置没存住。现在两半同口径:`0` 属于「0 = 关闭」那一类,
  不参与下限钳制。其余取值一字未动(1~7 → 8,200 → 96,区间内原样),预设走同一段合并所以一并修好。
  顺带拆开了 README 中英那句会被读成「0 也在 8~96 里」的措辞。

### 测试

- 新增 `scripts/verify-appearance-zero.cjs`:对 15 个取值**逐点比对两半口径**、0 的语义与邻接钳制,
  以及**真 HTTP 往返**(GET 整份文档 → 改字号 → 整份 PUT 回去 → 再 GET,并直接读落盘的存储文件)。
  修前实测 **8 条失败**(含 `GET → 8`、`store → {"fontSize":8}`),修后全过。已接入 npm scripts 与 CI。
- `npm test` 补 1 条:0 保持 0、4 夹到 8、200 夹到 96、预设内 0 也是 0。

### 说明

- 值改回与出厂默认相同时,用户增量会**整块消失**,所以存储文件里不会留下字面的 `fontSize: 0`。
  这是既有增量机制的行为,也是对的 —— 契约是「不残留被夹过的 8」+「读回来是 0」,脚本按此断言。

## [0.34.0] - 2026-10-02

### 新增

- **鲸尾摇速分档(`whaleTailMotion.tpsTiers`)**:tok/s 模式下摇速原本是**连续**映射(tok/s ÷ 16,
  夹在 2–6 次/秒)。6 次/秒是参考摇速(1.5)的四倍,尾巴只剩糊影。现在可以把它量化成 **2–5 个离散档位**,
  等距铺在 **2–4 次/秒**之间:只在下一次跨过档位边界时变一次速,上限也从 6 压到 4,上限档仍看得清翻转。
  - `0`(默认)= 连续,行为与改动前**逐点相同** —— 旧配置零改动;
  - `1` 档没有意义(那等于固定速度)、非 number、越界值一律退回连续;
  - 设置页「外观 → 鲸鱼尾巴」在 tok/s 模式下多一个「摇速档位」下拉,与「固定摇速」互斥显示。
  来自小黑盒用户 **洛水之蔚** 的反馈(署名见 `CONTRIBUTORS.md` / `CONTRIBUTORS_ZH.md`)。

### 测试

- 新增 `scripts/verify-whale-tail-tiers.cjs`(30 条断言):档位取值集合、上限、单调性、等待档、
  非法值退回连续、`fixed` / `enabled=false` 分支不受影响、两半校验一致,并**逐点确认不带该键时
  等于改动前的连续行为**。已接入 npm scripts 与 CI。
- 设置页浏览器测试新增 3 条:tok/s 模式渲染出档位下拉(默认连续)、选择档位真的写盘、
  固定模式下该下拉消失。

### 工程

- `release.yml` 会在打出 GitHub Release 之后**自动把 npm 的 `stable` 标签指向本次版本**
  (dist-tag 属于包本身,所以 fork 上配好 `NPM_TOKEN` 即生效);缺 token 时软跳过并留一条
  `::warning` 注解 —— 不重演「没人察觉的一步没做」。发版顺序因此明确为**先 `npm publish` 再推标签**,
  `CONTRIBUTING.md` / `CONTRIBUTING_ZH.md` 已同步。

## [0.33.2] - 2026-10-02

### 词库

- **把词库投稿 #122 / #123 的 3 条文案带进发布**:`正在演奏春日影…`、`正在投掷保龄球…`、`正在升级LV6…`。
  它们随 #123 合进了 `main`,但 `v0.33.1` 的标签指向的是**合并之前**的提交 —— 那个标签已经在 fork 与 npm 上
  发布过,不便重指,所以默认词库当时比最新 Release 多这 3 条。本版把它们带进一个 Release。
- 文案计数随之从 **1218** 变为 **1221**(仍是 14 个包)。README 中英的标语与文件树注释、`package.json` 的
  description、`lib/index.js` 的注释都已对齐;分项按合并后的词库核对:zh **674** / en **547** / 合计 **1221**,
  开 **945** / 关 **276**。

### 说明

- 本版除上述词库与计数外**没有任何代码改动**。它存在的意义是让四处公开标识重新对齐到同一个版本号:
  仓库的 `package.json`、本 CHANGELOG 的这一节、`v0.33.2` 的 Release 产物、npm 上的 `latest`。

## [0.33.1] - 2026-10-01

### 工程

- **删除内部 roadmap**:那份 roadmap 一直放在**仓库之外**(工作区根目录),从未进入 npm 包或 Release 产物 ——
  `package.json` 的 `files` 白名单里没有它,仓库里也没有对应文件。所以这次删除不改变使用者装到的东西。
- **清掉指向它的条目编号**:代码注释、验证脚本、浏览器回归页与 CI 里把 `E1` / `E2` / `E4` / `V3` / `V4` /
  `N1` / `N2` 当标签用的地方,一律改写成自解释的说明(如「N2 并发控制」→「并发控制」)。
  这些编号来自那份 roadmap,删掉之后无从解析 —— 属于「指向不存在文件的存活引用」。
  `CONTRIBUTORS` 里的 `Deepseek V4.1 Pro` 是模型名,未动。

### 说明

- 已发布版本的 CHANGELOG 条目(0.31.0 / 0.32.0 / 0.33.0 里的 `(V3)`、`(V4)`、`E4` 等)保持原样:
  那是对外已经发布的记录,不改写历史;本节的说明即是这些编号的收口。

## [0.33.0] - 2026-10-01

node 半边的两笔**必修债**:**推送式热重载**与 **If-Match 并发控制**。既有配置零改动兼容,
既有的写入方(手写脚本、文档里的 curl 流程)也照旧可用。

### 新增

- **推送式热重载**:新增 SSE 事件路由 `/plugins/dsh-status-rotator/events`。页面打开时就连上这条通道,
  配置一有变更(设置页保存、手改 `config.json`、外部 / 上游词库更新)服务端立刻推一条通知,
  已打开的页面随即重读 —— **不再靠客户端每 `reloadIntervalMs` 轮询**。
  - 通道连着时轮询**自动停掉**(页面长时间开着近乎零开销);通道不可用或断开时轮询自动回来,老宿主行为不变;
  - 服务端在**每次(重)连时先推一次当前 `ETag`**,所以断线期间错过的变更会在重连那一刻补齐,
    那一端不会停在一个没人再推的旧值上;
  - 服务端自己每 2 秒做一次本地变更检测(只 stat / 比对,无网络往返),因此手改文件与上游词库更新
    同样会推出去,而不是只有设置页保存才推;
  - 为什么是 SSE 而不是 WebSocket:宿主 webserver 的 `register` 类型声明明确允许 handler
    「hold the response open, e.g. SSE」,而 `registerUpgrade` 要自己实现 RFC6455 的握手与帧;
    两者对使用者是同一个结果(服务端主动推、页面不再轮询),选风险小的那条。
- **If-Match 并发控制**:配置路由的每个 `GET` 都带 `ETag`;`PUT` 带上 `If-Match` 时,
  基于旧副本的写入被 **409** 明确拒绝,响应体带当前 `ETag` 供重读后重试。
  - 设置页**始终**带 `If-Match`,所以两个设置页标签页之间不可能无声互相覆盖;
    冲突时它明确提示「这次保存被拒绝」并把编辑器拉回服务端的最新配置,不再让你对着一份
    服务端从没接受的编辑继续改;保存成功后服务端回新的 `ETag`,续写不会自己撞自己;
  - `GET` 支持 `If-None-Match` → **304**(轮询兜底路径不必再传整个 body);
  - `If-Match: *` = 显式无条件覆盖;不带 `If-Match` 仍是**无条件写** ——
    HTTP 里前提本来就是客户端自愿的,既有脚本与文档化的 curl 写入流程因此不受影响,
    代价是它们拿不到并发保护(README 里写明了这一点);
  - 保存**串行化**:前提校验与落盘之间不允许另一个 `PUT` 插队,否则两个并发请求可以双双通过检查再先后覆盖。

### 测试

- 新增 `scripts/verify-push-and-conflict.cjs`(真 HTTP + 真 SSE 长连接):`ETag` / `304` / `409` / `*` /
  无条件写、两个标签页的时间线(A 先写、B 用同一份旧配置写被 409 拒绝且 A 的内容没被覆盖、
  冲突响应带当前 ETag)、保存后推送、**手改词库文件后也能推出去**、以及断线重连后 `hello` 带当前 ETag。
- 修掉三处会让验证脚本污染环境的问题(都是本轮跑测试时踩出来的):
  - `verify-push-and-conflict.cjs` 把插件的**临时包副本**复制到工作目录再 import ——
    保存路径会写包目录的兼容镜像 `config.json`,而那个路径相对 `lib/index.js` 硬编码,
    直接 import 仓库里的 lib 会把测试内容写进仓库;
  - `verify-bank-auto-update.cjs` 与 `verify-phrase-hot-reload.cjs` 之前**没有隔离用户配置存储**,
    会把测试内容写进使用者真实的 `$DSH_HOME/status-rotator/config.json`;现在各用自己的临时目录;
  - `verify-push-and-conflict.cjs` 成功路径补上显式退出:插件的变更检测定时器还挂着,
    等事件循环自己排空是等不到的(会被外层 `timeout` 杀掉并以 124 结束)。

### 文档

- README(中英)「自动加载」一节改写为「自动加载 + 推送」,并新增「从外部写配置(ETag / If-Match)」
  小节,列出四种请求各自的结果。

## [0.32.0] - 2026-10-01

表现层的两条:**视觉主题化**(V3)与**弹幕增强**(V4)。既有配置零改动兼容 ——
两个功能的默认值全是「什么都不改」,不打开观感与 0.31.0 完全一致。

### 新增

- **视觉主题化(V3)**:新增 `appearance` 配置块 —— 字体族、字号、发光(含发光色)、文字动画
  (`none` / `breathe` 呼吸 / `glitch` 故障风)与状态行活动指示(`none` / `ring` 环形 / `bar` 条形)。
  随包五个**主题包**(`classic` / `neon` / `terminal` / `candy` / `glitch`),设置页「外观 → 主题包」
  选一个会同时写入外观与渐变色板,选完每一项仍可继续手调。
  - 全部用挂在**插件自己的文本 span** 上的 CSS 类实现,不新增 DOM 节点、不碰宿主原文与时钟;
  - `prefers-reduced-motion` 下呼吸与故障风自动停掉;
  - `fontFamily` 会写进 CSS,因此走严格白名单(字母 / 数字 / 空格 / 逗号 / 引号 / 连字符),
    其余字符一律拒绝而不是转义;
  - 活动指示表达的是「正在跑」而非百分比 —— 宿主不暴露回合进度;打字机锁宽已把它的宽度算进去。
- **弹幕增强(V4)**:五个可选行为,**默认全关** ——
  `hoverPause`(悬停在滚动弹幕上把它冻住,移开按剩余距离折算继续飞)、
  `clickCopy`(点击复制文案;没有剪贴板 API 时不做假反馈)、
  `phaseColors`(按当前相位给弹幕上色)、
  `adaptDensity`(同屏越接近 `maxCount` 发得越稀,页面不可见时几乎不发)、
  `avoidPointer`(落点躲开指针所在的高度带)。
  - :warning: 前两项会把弹幕层变成**指针目标**,与「弹幕层永不拦截指针」的承诺相反,
    所以必须显式打开;而且只有弹幕条目本身接指针,层仍是 `pointer-events: none`。
- **`sendDanmaku(text)`**:让一句自己写的文案立刻作为滚动弹幕飞过。它是 E4 注册接口的
  **加法式**扩展(`api.version` 保持 `1`,只有破坏性改动才递增),设置页「外观 → 弹幕」也有输入框;
  设置弹窗遮罩期间弹幕层是暂停的,这时发的会**排队、等遮罩关掉后补发**,而不是无声丢掉。

### 测试

- 新增 `scripts/appearance-danmaku-test.html`(浏览器页 `--page=appearance`,4 档):默认值 = 什么都不改 /
  主题包落到真 CSS(字体、字号、发光类与颜色变量、动画类、`::before` 指示器真的渲染)/
  指针交互(层只在显式打开时接指针、悬停真的冻住且位置不变、点击真的进剪贴板、相位分色生效)/
  自己发一条。已接进 `npm run test:browser` 与 CI。
- `npm test` 里「设置页草稿集中在 editorState 一处」的断言跟随新增的 `appearanceDraft` 更新 ——
  它正是为抓这种「新增草稿却漏进唯一清单」而存在的。

### 文档

- README(中英)新增「外观主题」「弹幕增强」两节,并在功能总览、测试页表与 E4 接口表
  (`sendDanmaku`)补上对应条目。

## [0.31.0] - 2026-10-01

三个 P0 一起发:**反重复洗牌袋**、**条件句与稀有句**、**对外注册接口**。既有配置零改动兼容 ——
不想用新能力的用户什么都不必做,升级后设置页、词库与状态行表现与 0.30.4 一致。

### 新增

- **反重复洗牌袋**:状态行按「语言 + 相位 + 权重模式」维护一袋句子,袋里的句子抽完之前不会重复;
  袋子抽空重开时先剔掉最近 N 条,所以跨袋的接缝处也不会撞上一句。权重在袋内照常生效。
  新增 `antiRepeat.recentLimit`(0~50)与 `antiRepeat.persist`(把记忆写进浏览器本地存储,
  刷新页面后不会立刻又看到同一句),设置页在「行为 → 反重复」。
  顺带换掉了旧的「每个元素记上一句」:那套记忆挂在会被宿主回收的 DOM 元素上,既会漏也会丢。
- **条件句(`when`)**:文案条目可以只在它描述的状态下出现 —— `tool`(工具名,`*` = 任意工具,多个用 `+`)、
  `retry`(正在重试)、`pending`(宿主在等你作答,可写布尔或数字)、`phase`、`hour`(本地时段,可跨午夜)、
  `firstTurn`(本会话第一回合);写出来的条件必须**同时**成立。有命中的条件句时只从它们里抽
  (否则一句 `bash` 会被上千条无条件句按权重淹没);一条都没命中就退回无条件句,状态行不会空。
- **稀有句(`rarity`)**:取 (0,1] 的抽取概率,让一句只在这么多次抽取里参与一次,彩蛋用。
- **设置页行语法**:词库编辑器支持 `文案 | 权重 | when:tool=bash | rarity:0.05`,
  修饰段写在行尾、顺序随意,正文里的 `|` 不受影响;与 JSON 条目**双向可逆**,
  打开设置页保存一次不会把条件洗掉。
- **对外注册接口(E4)**:浏览器半边通过 `ctx.provide("statusRotator", api)` 暴露服务,第三方插件
  `inject: ["statusRotator"]` 或 `ctx.get("statusRotator")` 即可注册:
  - `registerPack({ id, label?, phrases })` —— 具名词库包,与文档里的包走**同一个** `normalizePacks`;
  - `registerPlaceholder(name, resolve, { live }?)` —— 自带 `{name}` 占位符(默认按动态字段每秒刷新);
  - `registerPhraseProvider(fn | { id, provide })` —— 动态文案来源,每次轮换现算;
  三者都返回注销函数。第三方内容与随包内容走**同一条**选句管线(同文本去重 / `when` / `rarity` / 洗牌袋),
  且**不进配置文档** —— 注册不写配置,设置页保存也不会把它持久化或弄丢。

### 修复

- 词条比较键(`lib/index.js` 的 `normalizeEntry`)补上 `when` / `rarity`:该函数用来判断
  「用户条目是否已经在随包词库里」,只按 text(+weight) 归一的话,一条与随包条目**文本相同、
  但带条件**的用户条目会被当成随包内容从差异里剪掉 —— 保存一次条件就没了。
- 词条校验收紧:`when` 里的未知键、越界的 `hour` 与 `rarity` 一律拒绝。键名写错(如把 `tool` 写成
  `tools`)的结果是「这句永远不出现」,属于这个仓库一贯要避免的静默失败,不如在写盘前明确报错。

### 工程

- **设置页从 `apply(ctx)` 闭包里抽出**,成为模块级工厂 `createSettingsPage(deps)`:八个依赖
  (`locale` / `effect` / `toolMotionStatus` / `toolMotionListeners` / `getRuntimePreset` /
  `getLastLocale` / `isDarkTheme` / `onSaved`)显式传入,组件可脱离 `apply` 独立实例化、渲染与卸载;
  `apply()` 因此从约 4973 行降到约 3059 行。槽位注册(`settings.section`)、四个 Tab、
  字段与读写落盘行为全部不变 —— 变的只是依赖从隐式变显式。
- 设置页三处「保存后热应用」的连续调用收敛成一个 `onSaved` 回调;自有样式表改由 `dispose()` 释放。

### 测试

- 新增 `scripts/verify-settings-page.cjs`:设置页的**结构契约** —— 只用八个显式依赖即可实例化、
  渲染四个 Tab、字典走注入的 `locale` / `effect`、`dispose()` 摘掉样式表;并有护栏:
  工厂源码里不得再出现 `apply` 作用域的裸引用,防止抽取被无声改回闭包捕获。
- 新增 `scripts/verify-phrase-selection.cjs`:洗牌袋(袋内不重复 / 跨袋不撞最近 N 条 / 按语言与相位分键 /
  池子换了就重开 / 快照往返)、`when` 六种条件的正反例与 `hour` 跨午夜、`rarity` 掷骰、
  选句池的三种退化、设置页行语法双向可逆(含「JSON 条目 → 行 → 条目不丢条件」),
  以及 node 半边的校验与比较键。这些都是**眼睛看不出来**的故障。
- 新增 `scripts/external-api-test.html`(浏览器页 `--page=external`):一个真的第三方插件站在宿主
  上下文上接入 —— 在**随包词库清空**的前提下,只靠第三方内容点亮状态行(排除「其实还是随包内容
  在起作用」的假阳性),并验证非法注册抛错、之后才坏的 provider 被记进 `status().failures`
  且不影响状态行、注册全程不产生任何 PUT。
- 浏览器测试运行器支持页面自报完成(`window.__RESULTS_DONE__`):无头下页面可能被判为后台、
  定时器被降频,固定等待时长会读到一份**被截断但全过**的断言清单(最危险的假阳性)——
  现在等页面宣告跑完,等不到按失败处理;没设该标记的页面行为不变。

### 文档

- README(中英)新增「反重复(洗牌袋)」「条件句(`when`)与稀有句」「从另一个插件扩展它」三节,
  并在功能总览与测试章节补上对应条目。
- 设置页词库编辑器补上新的行语法提示(中英各四条);「行为」页新增「反重复」分组。
- 变更日志补上遗漏的 `[0.30.4]` 版本链接索引。

## [0.30.4] - 2026-10-01

### 文档

- 审计变更日志:修正 `0.30.2` / `0.30.3` 的**顺序**(此前 0.30.2 排在 0.30.3 之前);把**版本链接索引**从 `0.19.2` 补齐到最新发布的 `0.30.3`(未打过 tag 的版本链到 npm 版本页)。
- 补齐开源社区配套:**贡献指南**(CONTRIBUTING.md / CONTRIBUTING_ZH.md)、**行为准则**(CODE_OF_CONDUCT.md / _ZH,Contributor Covenant 2.1 改编)、**安全策略**(SECURITY.md:私密上报通道、配置路由的写栅栏与残余风险、投稿机器人的权限面)、**PR 模板**与 issue 模板引导(config.yml);五份文档纳入 npm 包 `files` 白名单,两份 README 的贡献段补上链接。

## [0.30.3] - 2026-10-01

### 文档

- README(中英):Quick start 与安装清单补**桌面端**安装命令 `dsh plugin --profile desktop add dsh-status-rotator`。
- README(中英)末尾新增 **Star 趋势**一节,内嵌 [star-history.com](https://www.star-history.com/) 生成的图表(随 star 增长自动更新)。

最新发布见 [GitHub Releases](https://github.com/01Virex/dsh-status-rotator/releases);词库条数在每次发版时同步刷新。

## [0.30.2] - 2026-10-01

### 词库

- `coding` 包:`正在修改J-space…`(thinking 分组)→ **`正在指控j-space数据造假…`**,英文对应行同步为 `Accusing J-space of faking its data…`。
- `internet-memes` 包:新增自嘲条目 **`正在写错贡献者名字…`**(为这次把贡献者链接写错的事自嘲)。

### 文档

- 贡献者名单:修正 **A7m** 的 GitHub 链接(此前一直写成 `github.com/A7m`,正确是 [`A7m0spHere`](https://github.com/A7m0spHere),两份名单与 0.30.1 的发布记录一并改回);新增小黑盒用户 **子夜** —— 她反馈了「同时出现两条鲸鱼尾巴」的 Bug(未在 GitHub 提 issue,后由 PR #112 修掉);云贡献者(整活区)15 条按原话更新。

### 说明

- `coding` 包那条是**替换**不是新增:`正在修改J-space…`(thinking 分组)被 `正在指控j-space数据造假…` 顶掉,英文对应行同步改写。上一轮我误判为「仓库里没有该条目、按新增处理」并在 `running` 里多写了一条 —— 本轮已把重复项删掉,全库只剩这一条。

## [0.30.1] - 2026-10-01

### 修复

- 修复开启鲸鱼尾巴摇动后与宿主原生图标**重合成两条鲸鱼**(回归起点为 #104)。宿主 0.2.0-rc.2 的 `runningIcon` 里真正可见的是 `<span class="runningWhaleAnimated">`(APNG mask),`<svg class="runningWhaleStill">` 只是被宿主 `@supports`/`@media` 关掉的静态回退;摇动原本只藏 `>svg`,命中的正是那个已经 `display:none` 的死元素,宿主图标留在原地与插件的 `tail-morph` 轮廓叠在一起。改为藏掉除 morph 外的**全部直接子级**(`>*:not(.dsh-status-rotator-tail-morph)`),对宿主后续更换实现也不再敏感。
- 浏览器回归夹具同步补上宿主的 APNG span 与那条 `@supports`/`@media` 级联(此前只摆一个 svg,回归根本复现不出来),并新增三条断言:宿主动画 span 被藏、静态 svg 被藏、插件自己的 morph 仍可见。冒烟另加一条静态契约,禁止把选择器改回只针对 svg 的窄写法。

## [0.30.0] - 2026-09-30

### 新增

- 鲸鱼尾巴新增 24 帧左右摆尾与 36 帧扭转摆尾，可与原版翻摆随机切换。随机模式每 4–8 秒选择另一种动作，在匹配的衔接姿态处经过 6 帧轮廓过渡；三种动作都支持 tok/s 调速、固定速度和炫彩。设置页「外观 → 尾巴动作」可选择，旧配置仍使用原版翻摆。关键帧按动作需要加载，暂停、回合结束及卸载时释放动画状态。

- 可选「工具调用时随机切换动作」：当前会话每次新的工具调用按设定概率触发，默认概率 35%(开关默认关闭)，支持 0–100%。历史和重复通知不触发，连续命中合并等待，经 6 帧衔接切换；固定动作模式也可使用。本地预览加入模拟调用按钮。

- 参考 [dsh-whale-sway](https://github.com/asdnmy123/dsh-whale-sway) 的相位保持与图标重绘恢复思路：速度变化时保留动画进度，宿主替换图标后恢复当前动作、速度与炫彩，随机模式不重新抽取动作或重置切换计划。适配记录见 [参考说明](./docs/whale-tail-reference.md)。

- **默认词库新增「广告」模块**(第 14 个 pack,**默认不启用** —— 想看的用户在设置页把「广告」这一包勾上即可):三条对外展示用的第一人称进行时文案,每条都带功能与出处(仓库地址),方便顺着找到对应的插件 ——
  - `正在优化提示词 github.com/WestFox-AwA/dsh-prompt-optimizer…`([WestFox-AwA/dsh-prompt-optimizer](https://github.com/WestFox-AwA/dsh-prompt-optimizer))
  - `正在操控 blender github.com/sixtysevenlf/dsh-blender-plugin…`([sixtysevenlf/dsh-blender-plugin](https://github.com/sixtysevenlf/dsh-blender-plugin))
  - `正在切换工作人格 github.com/shenA2024/whale-persona…`([shenA2024/whale-persona](https://github.com/shenA2024/whale-persona))
  中英各三条;沿用词库房子风格(每条以 `…` 结尾、不含 `;`),与完整性契约和投稿机器人的校验口径一致。`enabledPacks` 白名单里**不含** `ads`,所以新装 / 未改配置的用户默认轮播不到这三条。

### 验证口径

- `whaleTailMotion`(PR #109)的新增键默认关(`toolSwitchEnabled: false`)、`animation: "wag"` 保持原版翻摆、概率前后端各自钳到 0–1、枚举白名单两侧一致;生命周期有明确清理(无状态行/尾巴回归)。**保留**:「工具调用触发动作」目前只经单元/集成级断言(7 条)+ CI 验证,真实回合里的手感需用户自行开 `toolSwitchEnabled: true` 体验确认。

### 修复

- 修复工具事件早于图标挂载时丢失触发的问题：请求按会话保留，图标就绪后执行，并在回合结束、关闭功能、切换会话及卸载时清理。同一会话重新绑定不再重置工具选出的动作与请求；图标连续重建会恢复播放进度，正在进行的 6 帧过渡也能接着完成。

- 修复新版宿主在右侧栏关闭时无法定位当前会话、以及绑定尚未就绪后不再重试的问题，避免工具触发概率 100% 仍没有动作切换。通过主对话标记定位并检测绑定变化；设置页新增事件连接状态与调用/命中/切换统计，窗口隐藏期间的工具触发保留到恢复可见后播放。

## [0.29.0] - 2026-09-29

### 新增

- dsh 0.2.0 鲸鱼尾巴新增可选摇动:可按 tok/s 调速或设置固定摇速;启用此开关即明确选择播放摇动。
- 尾巴采用 24 帧矢量轮廓翻摆，支持炫彩；tok/s 模式最低每秒 2 次、最高 6 次，等待时保持最低速度。固定速度范围为每秒 0.25–6 次。

### 词库

- 词库投稿 [#102](https://github.com/01Virex/dsh-status-rotator/issues/102)(3 条,由 [@3418244301q-star](https://github.com/3418244301q-star) 投稿,合并为 #103);star 词库包(star-ask / star-route)随机器人刷新(#100)。

### 文档

- 贡献者名单补上鲸鱼尾巴摇动动画的作者 **[A7m](https://github.com/A7m0spHere)**(PR #104)与本次投稿人(见 [CONTRIBUTORS.md](./CONTRIBUTORS.md) / [CONTRIBUTORS_ZH.md](./CONTRIBUTORS_ZH.md))。

### 修复

- tok/s 调速接入新宿主的 `assistant/live-chunk` 事件，计入正文、推理和工具参数增量，避免旧快照字段缺失导致尾巴始终静止；历史重放不计入速度，切换会话重置采样。关闭文字实时刷新时，尾巴仍独立采样调速。

## [0.28.0] - 2026-09-28

### 新增 / 兼容

- **兼容 deepseek harness 0.2.0-rc.1**(npm `next` 档),并新增配置项 **`whaleTail`**:保留宿主的鲸鱼尾巴并让它跟着炫彩。
  - **0.2.0 的宿主变化**:运行中不再是折叠头 `button[data-turn-process]` 里的一段文本,而是会话流里独立的一行 `div[data-chat-running]`(隐藏读屏公告 span + 分隔条 + **DeepSeek 鲸鱼尾巴 SVG** + shimmer 文案);折叠头按钮改为**只在回合结束后**渲染(收起态摘要)。旧插件在 0.2.0 上因此**完全不会接管**(运行期间找不到 `[data-turn-process]`),状态行一直显示宿主原文。
  - **适配**:新增一条宿主路径 —— 认得 `div[data-chat-running]`,把插件那条线**挂进这一行的 `runningContent`**(鲸鱼尾巴之后),藏掉宿主自己的 shimmer 文案,时长照旧从宿主文本读(React 每秒整段重写它,插件只读不写)。刻意**不藏整行**:行里的 `role=status` 读屏公告必须留着(藏整行会让读屏用户失去「深度求索中」这个状态)。回合结束宿主撤行时,插件跟着释放,临时容器归零。
  - **`whaleTail`(默认 `false`)**:打开后把那一行的**鲸鱼尾巴留下**,与插件文案同一行(宿主 flex + `gap:6px` 布局天然对齐),并按「炫彩渐变」的色板给尾巴做流光 —— 尾巴 SVG 是 `stroke="currentColor"`,所以用 CSS 关键帧动画 `color` 即可;`prefers-reduced-motion: reduce` 下退回宿主原色。渐变关着时尾巴保持宿主原色。设置页在「外观」页(紧接着「炫彩渐变」一组),中英文案齐备。
  - **验证**:
    - 浏览器回归新增 3 档(**真实 0.2.0 DOM 逐字照抄的夹具**):`020-running-row`(接管那一行:线挂在 `#runningContent`、宿主文案被藏、读屏公告仍在、时钟与宿主 ±1s、尾巴默认藏)、`020-running-row-tail`(保留尾巴:类 + `animation-name = dsh-status-rotator-tail-rainbow`)、`020-running-row-finished`(宿主撤行 → 插件释放、`runningLines/runningLabels/runningTails` 归零)。三档全绿;泄漏档的前后容器规模一致(含三个新容器)。
    - 冒烟 +3 条(布尔接受 / 非法丢弃 / 默认 false)→ **381 通过 / 0 失败**。
    - **真实 0.2.0-rc.1 实例实测**(隔离 profile + 本插件,注入真实运行行):插件接管 ✓ 文案 = 插件短语 ✓ 时钟 23s ✓ 宿主文案藏起 ✓ **尾巴保留且 `animation: dsh-status-rotator-tail-rainbow` 在跑** ✓ 读屏公告完好 ✓ 控制台零报错 ✓;4 个 `<style>` 全部带 `data-plugin=dsh-status-rotator`(0.27.4 的修复在新宿主上同样成立)。
    - README 补「开一个隔离的测试实例」用法(独立 `DSH_HOME` + `--from-default-profile web`)。

## [0.27.5] - 2026-09-27

### 修复

- **设置页「行为 → 标签页标题」整组从不自动落盘(0.27.0 新增的设置组)**([#96](https://github.com/01Virex/dsh-status-rotator/issues/96),报告人 [@Ztyss](https://github.com/Ztyss))。
  现象:打开「接管标签页标题」/ 改模板 / 改间隔后无报错、但什么都没写盘,刷新就弹回「关」,`config.title` 从不落盘。
  - **根因**(报告人定位准确):「改即写盘」的去抖 effect 在**签名实参**与**依赖数组**两处都漏了 `titleDraft`,而 `editorSignature` 本身是序列化它的 —— 只改标题时 effect 根本不重跑;即便因其它字段重跑,签名里也没有标题部分,`signature === baseline` 会提前 return(改动只能「搭便车」)。`commitDrafts` 的 `useCallback` 依赖数组同样漏了它,闭包捕获旧草稿 —— 搭上其它写盘也可能存进**旧的标题值**。除报告点出的三处,还多找到一处:commitDrafts 里算的 `setBaseline` 签名也漏了标题,会让基线永远对不上。
  - **修法(结构性,而非只补字段)**:把全部草稿状态收成**单一来源** `editorState`(含 `titleDraft`),签名实参、`dirty`、effect 依赖数组全从它走 —— 以后新增草稿字段只改这一处,不会再出现「新设置组漏进签名 / 依赖 → 改了什么都不写盘」。自动落盘 effect 现在同时依赖 `editorState` 与 `commitDrafts`,不会再拿到旧草稿或旧回调。
  - **防回归**:设置页浏览器回归 +7 条 —— 切到「行为」页 → **单独**拨标题开关 → 断言真的发出 PUT 且 `config.title.enabled === true`;再关掉 → 断言写的是 `false`(不是闭包里的旧值)。**修前两次 toggle 的 PUT 都是 0(正是报告的现象),修后各 1 条且值正确。** 冒烟另加 4 条静态契约(草稿状态集中在 `editorState`、不许再手搓局部签名对象、自动落盘 effect 必须依赖 `editorState` + `commitDrafts`、`editorSignature` 只能吃 `editorState` 或 `applyDoc` 的结果),冒烟 374 → **378 通过 / 0 失败**。

## [0.27.4] - 2026-09-26

### 修复

- **插件的 `<style>` 没打 `data-plugin`,会被别的插件认领后删掉 —— 设置页整套样式消失**([#94](https://github.com/01Virex/dsh-status-rotator/issues/94),报告人 [@IThinkItsaName](https://github.com/IThinkItsaName))。
  - **机制**(报告人定位准确,宿主侧已核对):宿主模块系统在**工厂体跑完之后**才认领样式 —— `@deepseek-ai/dsh-client-modules` 的 `claimStyles(id)` 把当下**所有没有 `data-plugin` 的 `<style>`** 标成自己的,而 `removeOwnedStyles(id)` 会在**该模块 revision 变化**时删掉名下的标签。归属于是由时间顺序决定:谁后物化谁把这些无主标签认走,之后它一变更,插件的样式跟着消失 —— 症状是间歇性的(重启有时又好)。
  - **本插件是受害者**:4 个 `<style>`(`layout-style` / `style` / `danmaku-style` / `settings-style`)一个都没打标记。其中 `settings-style` 在**设置面板组件里**创建,首次打开设置页才诞生 —— 那时所有模块都物化完了,它一直处于无主状态,等着被下一个物化的模块认领。
  - **修法**:新增 `createOwnedStyle(id)` —— 建完立刻 `setAttribute("data-plugin", "dsh-status-rotator")`(归属 id = 包名,与宿主自带插件 `dataset.plugin = "@deepseek-ai/dsh-client-..."` 同一套);4 个创建点全部改走它。打了标记的标签不会被任何模块认领(宿主注释里写明 pre-tagged 不会被认领)。
  - **防回归**:冒烟 +4 条静态契约(只在 `createOwnedStyle` 里建 `<style>`、建完必打标记、四个标签一个不漏、归属 id = 包名);设置页浏览器回归 +3 条**行为**断言 —— 照搬宿主那两步(认领所有无主 `<style>` → 删掉「那个模块」名下的标签),断言插件样式仍在、设置页仍带样式(取样 `.dsh-sr-toggle` 高度 20px)。**修前 3 条全红(4 个标签全无标记 → 被认领 → 被删 → 高度掉到 6px),修后全绿。**

## [0.27.3] - 2026-09-26

### 修复

- **一次设置页保存会把外部词库的内容当成「用户改动」冻进存储,README 承诺的「把包从外部词库删掉即可回到设置页管理」因此失效**([#92](https://github.com/01Virex/dsh-status-rotator/issues/92),报告人 [@mulinyang041](https://github.com/mulinyang041);报告文本由报告人机器上的 DSH agent 写就、账号主人授权发布)。
  - **根因**(报告人定位准确,我复核 + 端到端补齐):GET 返回的是**所有层合并后的整份文档**(外部词库优先级最高),设置页又把它整份 PUT 回来;而保存时算「用户改动」的基准只有「内置 + 自动更新词库」,**不含外部词库层** —— 词库塞进去的包于是被记成用户改动。存储层优先级高于 file / remote 层,所以之后按 README 把该包从外部词库删掉时,存储里那份快照会顶上来。
  - **还有一半在镜像上**(报告人标为「没往下追」的那点):保存时写进包目录的兼容镜像 `config.json` 是「整份已生效文档」,里面同样带着词库内容 —— 只修差异基准还不够,镜像会把那份内容继续供出来(上游内容同理:它**没**被冻进存储,但被镜像留住了)。
  - **修法**:① 判定基准改为 [`userChangeBaselineDocument()`](./lib/index.js)—— 内置 + 自动更新词库 + **外部词库**(三者都不是用户改的设置);`absorbFileLayer` 与老宿主设置存储走同一基准;② 兼容镜像只写**用户自己的配置**(内置 + 老宿主设置 + 本次算出的用户差异),刻意不含外部词库与自动更新这两层 —— 它们各有交付通道(词库文件 / 上游缓存)。
  - **防回归**:新增 [`scripts/verify-external-bank-ownership.cjs`](./scripts/verify-external-bank-ownership.cjs) —— 真实插件 + 真实 HTTP 路由 + 真实词库文件 + 整份 PUT 跑完整时间线,13 项断言(词库 / 上游 / 用户真改动三组对照);**修前 5 项红(A③A④A⑥、B③B④),修后全绿**,已进 CI 的 test 档。冒烟另加 2 条纯函数断言(外部词库内容不进设置;用户自己改的词条仍进设置)。

## [0.27.2] - 2026-09-25

### 修复

- **设置页保存被 0.27.1 新加的护栏挡死:弹幕关不掉(开关拨过去没写盘,重读又拨回来)。**
  0.27.1 为防「配置没读到时提交残缺文档」加了一道护栏,但它把 `docRef.current` 当成「读到的文档」——
  而 `docRef` **只在 `persist()` 里赋值,即第一次保存之后才有值**。于是全新打开的设置页里,任何一次
  改动(开关、下拉、输入)都被拦下,并显示「配置还没读到,先点『重读』再改」:
  - 界面乐观地显示成关,但**没有任何 PUT 发出** → 存储里仍是开 → 下次读盘 / 刷新弹幕照飞;
  - 「重读」会先 flush 草稿(再次撞护栏)再读盘,所以**重读也没用**(用户报的正是这条);
  - 0.27.0 没有这道护栏,而是把这份残缺文档**静默写了下去** —— 所以这个坑在 0.27.1 才显形。
  - **修法**:新增 `writeBase()` —— 基准文档 = 上一次写盘的那份(`docRef`)→ **本次读到的文档**(`doc`)
    → 两者都没有才拒绝(那才是真正的「没读到」);`persist()` 与 `commitDrafts()` 共用它,并把 `doc`
    补进两个 `useCallback` 的依赖数组(否则闭包永远看到首帧的 `null`)。
  - **防回归**:新增真浏览器回归页 [`scripts/settings-save-test.html`](./scripts/settings-save-test.html)
    (迷你 React:真 state / 真 effect / 真事件 + fetch 替身):打开设置页 → 点弹幕开关 → 断言真的
    发出 PUT、写的是**整份文档**、且 `danmaku.enabled === false`。修前 `puts=0` 且出现拦截提示,
    修后全通过;该页已进 `npm run test:browser` 与 CI 的 `browser` 档 —— 之前 `label` 页的 React 替身
    是**只渲染**的(`useState` 的 setter 是空函数),设置页的保存路径从来没被测到,这就是它能溜进 0.27.1 的原因。

- **状态行每接管一个回合就泄漏一个已脱离 DOM 的标签元素([#87](https://github.com/01Virex/dsh-status-rotator/issues/87),报告人 [@yihefeikong-rgb](https://github.com/yihefeikong-rgb))。**
  `lib/client.js` 的 `turnLabels`(折叠头按钮 → 宿主那个每秒被整段重写的标签元素)只 `set`、
  从不 `delete` / `clear`:回合释放(`releaseStatusLine`)漏了它,插件卸载的清理也漏了它 ——
  是当时唯一两条清理路径都没覆盖的容器。每接管一个回合就多持有一份 detach 掉的 React 元素,
  长时间在同一会话里跑会随回合数线性增长(实测:连续 8 个回合,容器规模 1 → 9,每回合净增 1)。
  - **修法**:`releaseStatusLine()` 补 `if (button) turnLabels.delete(button)`(与相邻的
    `turnLines.delete` 对称);插件卸载时把按按钮索引的容器一并 `clear()`。
  - **防回归**:浏览器回归新增 `?case=leak`(真实插件跑 8 个完整回合,断言每回合释放后净增为 0、
    结束后容器回到开跑前的规模;修前 `netAfterRelease=[1,2,3,4,5,6,7,8]`,修后全 0);冒烟测试加一道
    静态契约(每个 per-turn 容器有写入就必须有 delete/clear,且 `releaseStatusLine` 必须同时清两个按钮键容器)。
  - 顺带把**浏览器回归接进 CI**(新增 `browser` job:弹幕 / 布局 / pending / 标题四页 + 0.1.7 状态行与泄漏场景)
    —— 这类 DOM 生命周期问题以前只在本地跑得到。

### 测试

- 冒烟 356 → **368 通过 / 0 失败**(新增清理契约 12 条);浏览器回归 **5 页**(弹幕 / 布局 / 设置页保存 / pending / 标题)
  + 17 档状态行场景(含泄漏)全过。

## [0.27.1] - 2026-09-25

### 修复

- **设置页「共 0 个包,已启用 10 个」「暂无词库包」,内置词库整个消失(外部反馈)。**
  保存路径把「提交上来的文档里没有某个包」当成用户删包写进存储(墓碑),而设置页的词库包区
  **只有启用 / 停用开关,没有删除按钮**(预设才有删除)—— 所以那只可能是文档不完整
  (设置页开着时插件升级 / 上游新增了包 / 这次提交的文档是残缺的),不是用户删的。
  一旦记成删除,生效文档就成了 `packs: []` 而 `enabledPacks` 还剩 10 条:设置页显示 0 个包、
  内置词库全部失效(只剩用户自己写过的那些词条),而且此后每次保存都会把这份残缺文档再存一遍,
  永久卡住。
  - **修法**:保存路径(用户配置存储 + 老宿主设置存储)不再写词库包的删除墓碑 —— 词库包只做
    「合并且改内容」;预设的删除墓碑保留(预设确实有删除入口)。
  - **已受影响的安装自动恢复**:读存储时清掉词库包墓碑并把干净的那份写回(幂等),老宿主设置
    存储的收敛版本 +1 顺带再清一遍 —— 升级后打开设置页就是完整的 13 个包,用户自己的词条一条不丢。
  - 顺带堵住另一个会丢设置的口子:**配置还没读到时不许保存** —— 那时提交出去的是「只有本次动过的
    键」的残缺文档,而保存是整份替换存储。
- **投稿机器人 / CI(在 `scripts/` 与 `.github/`,不在 npm 包的 `files` 里)**:投稿分支不再卡冲突
  (main 前进 / 每 6 小时 / 手动时按当前 main 重建所有开着的投稿分支,[#78](https://github.com/01Virex/dsh-status-rotator/pull/78));
  **分号类标点一律拒绝**并在复核不过时自动关闭 PR([#81](https://github.com/01Virex/dsh-status-rotator/pull/81));
  重复键哨兵(读库 + 写盘回读 + `npm test` 断言);修好 `apiCreatePr`「响应体读两次」导致 PR 标签从未打上的问题;
  Star packs 在 fork 里跳过、刷新 PR 的合并流程修好([#66](https://github.com/01Virex/dsh-status-rotator/pull/66) / [#69](https://github.com/01Virex/dsh-status-rotator/pull/69))。

### 测试

- 冒烟 342 → **356 通过 / 0 失败**:词库包墓碑 7 条(含「提交 `packs: []` 也删不掉内置词库」)、
  重复键哨兵 5 条、分号过滤 2 条。
- `verify-settings-survive-upgrade.cjs` 新增场景 E(存储带词库包墓碑 → 启动即恢复 13 个包、存储被治好、再保存也不再删)。

## [0.27.0] - 2026-09-25

### 新功能

- **标签页标题进设置页**:DSH「设置 → 状态文案 → 行为」页新增「标签页标题」一组 ——
  开关、标题模板(每行一条,轮换)、空闲时的标题、轮换间隔。保存后与其余设置一起写进插件的
  配置存储(`$DSH_HOME/status-rotator/config.json`,升级不丢),不用再手改 `config.json`;
  关着的时候插件**完全不碰** `document.title`。默认仍是关闭。

### 修复

- **不再抢别人的标签页标题(与 [oh-my-dsh](https://github.com/gulagala001/oh-my-dsh) 的品牌名替换互撞)。**
  反馈:「卡死的根因是第三方插件 dsh-status-rotator 抢标题 + OMD 改品牌名互撞。」查下来冲突在我们这边,
  而且是两条路径:
  - **根因**:插件的还原分支写的是「读回来的值 ≠ 启动那一刻缓存的值就写回去」。它把
    `document.title` 当成自己的地盘,于是**任何**别的标题写者都会被顶掉 —— 包括宿主自己写的
    会话标题(`<会话名> — DeepSeek Harness`)。真浏览器实测(`omd=off` 对照):宿主写完会话标题,
    插件下一拍就把它换回启动时的产品名,标签页上再也看不到会话名。
  - **与 OMD 永不收敛**:OMD 给 `document.title` 装了一对访问器,把写入值结尾的 `DeepSeek Harness`
    换成 `Oh My DSH`(v0.1.7-rc.2.2 起,它自己 issue #12 的修法)。我们读回来的值因此**永远**不等于
    写进去的值 → 每一拍都重写一次。装载顺序还会决定表现:OMD 后装(插件先缓存了原始产品标题,
    报告人的顺序)是每拍重写;OMD 先装则是会话标题被顶成品牌名。更早那版 OMD 用观察器改标题时,
    这种高频重写会变成两边互相触发 —— 也就是「疯狂闪现 / 卡死」那类现象。
  - **修法**:标题加**所有权**概念 —— 只有「插件自己写上去的标题」才谈得上交还
    (`titleWritePlan`,纯函数);没持有过就一个字都不写,持有过则交还**最近一次别人写的标题**
    (用「当前值 ≠ 我们上次写进去的值」判断那是别人写的,而不是还一个启动快照)。卸载路径同样只交还自己的标题。
  - **判断:应当兼容,而且由我们这边修** —— 这是我们自己的缺陷(不装 OMD 也会顶掉宿主的会话标题),
    OMD 的替换是合理的产品行为,而且 OMD 的插件目录里还把 dsh-status-rotator 列为推荐插件。

### 测试

- 冒烟 333 → **342 通过 / 0 失败**:新增「标签页标题所有权」一节(`titleWritePlan` 的四种决策 +
  `normalizeConfig` 对 `title` 完整字段 / 简写 `true|false` / 非法字段逐项剔除)。
- 新增真浏览器回归 `scripts/title-coexistence-test.html`(+ `--page=title`,5 档):把
  **oh-my-dsh 的品牌替换代码逐字搬进来**,跑真实 `lib/client.js`,按 `omd=off|before|after` ×
  `title=0|1` × `flip=1` 组合量「写了几次 / DOM 变了几次 / 标题变了几次」:
  - 修前:omd=after 一档 2.6 秒窗口里 **10 次重写**、标签页停在 `Oh My DSH`(会话标题丢失);
    omd=off 也把会话标题换成了产品名 → 4 档失败。
  - 修后:5 档全过 —— 关着标题功能时写入 1 次(只有宿主那一次),开着时接管一次后稳定,
    中途关掉则**只交还一次**、标题回到宿主那一份。
- `label-layout-test.html` 的设置页渲染断言扩到「行为」页:标签页标题分组 / 开关 / 模板 / 空闲标题 /
  间隔五项都在设置页里(改设置页 JSX 时最先坏在这里)。

## [0.26.1] - 2026-09-25

### 修复

- **设置不再随插件升级重置(issue #51,[#51](https://github.com/01Virex/dsh-status-rotator/issues/51))。**
  v0.23.3 修的是「同一份设置第二次保存时差异被镜像顶掉」,但报告人在 v0.26.0 上依然每次都回退 ——
  这次找到了真正的那一环:**升级后配置根本没有第二份副本**。
  - **根因**:插件一直把持久化托付给 dsh 官方设置存储(老 API:`settings.register(ns, schema)`),
    而 `@deepseek-ai/dsh-settings` 0.1.7-rc.1 的 settings 服务只有
    `describe` / `update` / `replace` / `mutate` / `configure`,**没有 `register()`**
    (也没有 `document`)。于是 `getSettingsApi()` 在真机上一直返回 null,整条官方存储链路
    静默失效 —— 设置只剩插件目录里的 `config.json` 一份,而 npm / Release 升级会把插件目录
    **整体替换**,那份文件连同设置一起没了,下次启动回落到随包默认值(关掉的弹幕又打开)。
    仓库自己的 `verify-settings-survive-upgrade.cjs` 没抓到,是因为它的 settings 替身
    **替身多了一个真机没有的 `register()`**,把这条链路照绿了。
  - **修复**:持久化落到**插件自己的数据目录** `$DSH_HOME/status-rotator/config.json`
    (可用 `DSH_STATUS_ROTATOR_CONFIG` 覆盖),它不属于任何包,升级不会碰;写不进去直接
    返回 500,不再假装保存成功。装载顺序变为
    **内置默认 → 插件目录 `config.json` → 自动更新词库 → 老宿主设置存储 → 用户配置存储 → 外部词库**。
  - **存量迁移**:插件目录 `config.json` 里手改过的部分(README 允许的用法)会在它还在的时候
    被搬进用户配置存储 —— 每次 GET 都会检查,最迟一个 `reloadIntervalMs` 就搬完,不用等重启
    (重启往往已经在升级之后,那时文件早没了)。存储里记着「这份镜像是我写的」的内容指纹,
    自己写的镜像不会被重复搬(否则会把写镜像那一刻的上游词条快照冻结成用户改动);
    Release 包里那份 `config.json` 是 `config.example.json` 的拷贝,搬它不产生任何差异。
  - **改回默认值也能生效**:存储里存的是「提交的完整文档与随包基准的差异」,每次都从零重算
    (而不是和上一次的差异叠加)—— 把弹幕改回开启后,差异里就没有 `danmaku` 这一项了,
    不会再被旧值焊死。
  - 包目录 `config.json` 仍然作为**兼容镜像**写出(文档 / 老版本 / 手改工作流都认它),
    但写它失败不再让保存失败(包目录在 pnpm store / 解压包里可能只读,而数据已经在用户配置存储里)。

### 测试

- 冒烟 319 → **333 通过 / 0 失败**:新增「用户配置存储」一节(路径 / 原子写 / 内部键不泄漏 /
  差异重算 / 改回默认值 / Release 包拷贝不产生差异 / 存储损坏保留上一次成功值)。
- `verify-settings-survive-upgrade.cjs` 补齐**真机形状**的宿主替身(没有 `register` / `document`,
  只有 `describe`/`update`/`replace`/`mutate`)并新增场景 D:设置页 PUT → 升级 → 设置仍在 →
  改回默认值 → 再升级 → 仍然是改回来的值。场景 A / B(手改 `config.json` → 升级)、
  C(老宿主设置存储)同时转绿;对 v0.26.0 的代码跑这份验证会在场景 D 上复现报告人看到的回退。
- CI 增补一步 `node scripts/verify-settings-survive-upgrade.cjs`:这份验证此前不在 CI 里,
  正是「设置跨升级」这条链路长期没人跑起来的原因。

## [0.26.0] - 2026-09-24

### 新功能

- **状态行文案来源 `labelSource`**:`"phrases"`(默认,轮换短语库)/ `"host"`
  (只用宿主原文 `Deep diving...` / `深度求索中`,完全不轮换)。设置页「状态文案」页签里有同名下拉框,
  `config.json` 与预设里也能直接写。
  `"host"` 不只是换文案 —— 插件自己那条线的外观**逐项对齐 dsh 0.1.6 的 `.turnStatus`**
  (`packages/client/ui-chat` 的 `ChatView.module.css`,原文已逐条核对):
  - `font: var(--dsw-font-s-strong-14)` —— 即 `500 14px/22px <family>`,**字重是 500**;
    插件此前硬编码 `font-weight: 600`,比旧版粗一档(这次一并改掉);
  - `height: calc(26px + var(--dsh-content-font-delta,0px))`、`display: inline-flex`、
    `align-items: center`、`flex: none`、`white-space: nowrap`;
  - 同一套 shimmer 渐变(`linear-gradient` 的四个色标、`background-size: 250% 100%`、
    `background-position: 100% 0`、`1.8s linear infinite`、`background-clip: text`)与
    `prefers-reduced-motion` 降级;
  - 时钟照抄 `.turnStatusClock`:`font: var(--dsw-font-xs-13)`、13px、
    `line-height: calc(20px + …)`、`tabular-nums`、caption 色、`margin-left: 8px`、400 字重;
    并且**按旧版时机出现** —— 0.1.6 是 `elapsedMs >= 15e3` 才渲染时钟,`"host"` 模式照做。
  - 文案直接落字、不走打字机(旧版就是「一上来就写着」的观感)。
  - 旧宿主(≤0.1.6)在 `"host"` 模式下**完全不碰**:它的 `role="status"` 本来就写着宿主原文,
    插件既不改文案也不加渐变。

### 修复

- **状态行不再变成一条空行:没有文案可轮换时回落宿主原文**(「deep diving 不见了」)。
  0.1.7 上插件会藏掉宿主那行、改成自己在输入框上方画一条线;一旦短语库为空
  (典型场景:插件装上了但没 `config.json`),`textsForPhase()` 返回 null → `refresh()`
  直接 return —— 那条线就只剩时钟、一个字都没有,而宿主的「Deep diving for 12s」已经被藏了。
  现在 `"phrases"` 模式同样回落宿主原文,不再是空行;旧宿主(≤0.1.6)保持「不碰」策略。
- **适配 dsh 0.1.7-rc.1**。rc.1 把回合行的渲染条件改了(对照 `TurnProcessNodeView` 源码):
  - alpha 时代:`if (!turnProcess.foldable) return null` —— 没有可折叠内容的回合**什么都不渲染**;
  - rc.1:`if (turn?.start === void 0 && turn?.status !== "closed") return null` —— **每个**回合都渲染,
    且 `canCollapse = foldable && hasContent && !alwaysOpen`,不能折叠时按钮带 `disabled`、
    `data-open` 恒为 true、不渲染 chevron(`open = !foldable || open`)。
  插件依赖的 DOM 契约(`button[data-turn-process]` > `span.label`,标签文本每秒被整段重写)未变,
  接管 / 释放逻辑照常工作;回归页按 rc.1 源码与 CSS 重做夹具并新增一档锁死这个差异。

### 测试

- 冒烟 311 → **319 通过 / 0 失败**:新增 `labelSource` 白名单(`normalizeConfig` / node 半区
  `sanitizeConfigDocument`,含预设内)与 `labelPlanFor` 决策表(短语库有无 × 是否插件自己的线 ×
  两种来源模式,共 8 组)。
- 0.1.7 真浏览器回归 11 → **15 档全过**:
  - `?case=running-simple` —— rc.1 的 `disabled` + `data-open` + 无 chevron 简回合,照样被接管;
  - `?case=no-phrases` —— 完全没有文案来源时,状态行回落宿主原文(不再是空行);
  - `?case=host-only` / `?case=host-only-clock` —— `labelSource: "host"` 下,把插件那条线与页面里
    一份**逐字同构的 0.1.6 `.turnStatus` 参考元素**做 computed style 逐项比对(字体族 / 字重 /
    字号 / 行高 / 盒高 / display / 渐变 / 动画 / 时钟的每一项),并断言字重 = 500;
    时钟按旧版 15 秒时机出现(两种 elapsed 各一档)。
  - 夹具保真度同时修正:旧宿主的 `.EvIC1a_turnStatus` 改为照抄真实 token
    (`--dsw-font-s-strong-14` = `500 14px/22px <family>`),此前夹具写的是 600 —— 正是因为夹具错了,
    插件把字重写成 600 才一直没被发现。
- 弹幕回归页 13 档全过,既有挂载 / 顶底弹幕 / 标签布局 / pending 套件无回归。

## [0.25.0] - 2026-09-22

### 新功能

- **观测通道:把重试从 `Deep diving…` 后面拎出来**(参考
  [deepseek-harness discussion #3669](https://github.com/deepseek-ai/deepseek-harness/discussions/3669))。
  那份讨论的结论是:重试 / 传输降级这些状态今天只躺在 host stderr 里,缺的是**结构化数据通道**,
  而「渲染」这半外部插件自己就能做。这条正好落在本插件身上,于是按讨论里的三条原则实现:
  - **只吃协议事件**:从客户端会话绑定的事件窗口(`binding.eventSource`)里读
    `llm/retry` / `llm/retry-started`(dsh-llm-retry 追加的结构化事件),**不解析任何日志或界面文本**;
  - **词汇表 provider 中立**:`provider` / `code` 原样透传,不枚举产品专属码;`failure.message`
    绝不出境,`code` 还要过一道「短 token」脱敏(URL / 路径 / 凭据一律丢弃);
  - **显式降级**:拿不到事件窗口的宿主上什么都不显示(不猜次数),`step/start`、`turn/end`、
    `assistant/message` 到达即清空。
- **状态行徽标**:时钟后面加一枚小胶囊,模板由 `config.details.badge` 决定(默认
  `⟳ {retry}/{max}`,空串 = 不显示徽标、只留占位符);新旧宿主都渲染(0.1.7 的状态行与
  ≤0.1.6 的 `role=status` 状态行)。
- **新占位符**:`{retry}`、`{retryMax}`、`{retryProvider}`、`{retryCode}`、`{detail}` ——
  文案与标题模板都能用,例如 `"正在重试 {retry}/{retryMax}…"`。
- **配置**:`config.details = { enabled, badge }`;`config.example.json` 同步。

### 修复

- **设置弹窗持续闪烁:弹幕层在全屏 `backdrop-filter` 遮罩后面**([#60](https://github.com/01Virex/dsh-status-rotator/issues/60))。
  dsh 的设置弹窗遮罩是「`position:fixed; inset:0; z-index:1000` 容器 + `position:absolute; inset:0;
  backdrop-filter:blur(2px)` 子层」,遮罩本身只有 24%(浅色)/ 50%(深色)不透明;弹幕层在它后面
  每 2.5 秒发一颗、每颗横穿 18 秒,浏览器于是每帧重算整屏模糊 —— 表现就是设置弹窗一直闪
  (停用插件即恢复,正是这个原因)。新增 `danmaku.pauseBehindMask`(默认 **true**):检测到
  「铺满视口 + 自带 `backdrop-filter`」的宿主层就**整体停摆弹幕** —— 拆掉弹幕层与在途条目
  (连同它们的 CSS 过渡)、清掉发射定时器、还原挂载点上的 `isolation`;遮罩一关掉立刻重建并继续发射。
  - **检测**:视口四角 + 中心共 5 个点做命中测试(`elementsFromPoint`),只对命中栈里的元素读
    computed style —— 不遍历整棵 DOM;DOM 变更合并成 250ms 一次探针,`rescanAll` 每 2 秒兜底
    (只切样式、不增删节点的显隐也能发现)。
  - **不误伤**:菜单 / 卡片这类小面积模糊不满足「铺满视口」,铺满视口但没有模糊的浮层不满足第二条;
    顶部留空 80px 的引导遮罩(`OnboardingSurface`)同样不命中。
  - **可关**:`"danmaku": { "pauseBehindMask": false }`(设置页「弹幕」页签里也有同名开关)
    回到旧行为,弹幕在遮罩后面照跑。
- **实时引擎在 dsh 0.1.7 上一直没接上**:0.1.7 的 `sessions.list` 快照只剩
  `ids / byId / phase / projectionsBySession`,**不再有 `current`**,而插件只读 `current`
  → `connectSession` 从未被调用,`{model}` / `{tps}` / `{pending}` 这些实时字段与
  观测通道在 0.1.7 上全是死的(实测确认)。现在当前会话 id 三路取:
  `sessions.list.current`(≤0.1.6)→ `localStorage["dsh.sessions.current"]`(0.1.7 的界面
  自己记的选择)→ DOM 的 `[data-sidebar-right-session]`;并在 2 秒兜底轮询里重接一次线,
  服务晚到(0.1.7 常见)或用户切会话都能自动跟上。

### 兼容性

- **dsh 0.1.7-alpha.1**:实测 `binding.eventSource` 存在(`eventSource=true`,窗口里有事件),
  观测通道真的能跑;实时引擎经上面三路修复后接通。
- **dsh ≤0.1.6**:走 `sessions.list.current`,状态行是旧位置那行 `role=status`,
  徽标挂在它上面(回归场景 `retry-old-host` 覆盖)。
- **没有事件窗口的宿主**:静默降级(场景 `no-events`),状态行其余功能不受影响。

### 测试

- 冒烟 289 → **311 通过 / 0 失败**:新增观测通道纯函数断言(事件折叠、`retry-started` 同链校验、
  `step/start` 清空、脏数据 → null、`safeObservationToken` 脱敏、徽标模板与孤立斜杠收拾),
  以及 #60 的遮罩判定断言(`hasBackdropFilter`、`danmakuMaskOverlayHit` 的命中 / 不命中 /
  容差 / 脏数据,`pauseBehindMask` 在浏览器半区与 node 半区的归一化)。
- 真浏览器回归 8 → **11 档全过**:新增「观测通道:重试徽标出现 / 跟随窗口 / 清空」「旧宿主也显示徽标」
  「无事件窗口 → 不显示徽标、不猜次数」。
- **弹幕回归页 6 → 8 档**:新增 #60 的两档宿主遮罩场景 —— `?mask=1` 先让弹幕跑起来,再挂上与
  dsh 设置弹窗同构的全屏遮罩(`position:fixed;inset:0;z-index:1000` + 子层
  `backdrop-filter:blur(2px)` + 居中 380px 卡片),断言遮罩出现后弹幕层被拆除、在途弹幕清零、
  面板 `isolation` 还原、静置 1 秒不再发射,遮罩移除后弹幕层自动重建并重新发射;
  `?mask=1&pause=0` 是关掉 `pauseBehindMask` 的反向对照(遮罩期间必须照跑)。
- 既有弹幕 / 布局 / pending 套件无回归;线上 0.1.7 GUI 验收 11/11(状态行位置 / 对齐 / 文案 /
  时钟 / 折叠头 / 读屏公告 / 徽标节点就绪且无重试时不冒出来)。

## [0.24.0] - 2026-09-22

### 变更

- **状态行搬回 dsh 旧版位置(输入框上方、对话下方)**:0.1.7 把回合状态塞进了
  `button[data-turn-process]` —— 回合折叠头,长在回合开头;长回合里它早被滚出视口,
  「替换 deep diving」等于白替换。dsh ≤0.1.6 的状态行在另一个地方:`ChatView` 里
  `ChatNodeList` 之后渲染的 `TurnStatus`,样式 26px 高 / `nowrap` / `inline-flex` /
  自带 shimmer 渐变,时钟 13px + 8px 间距(见旧版 `.turnStatus` / `.turnStatusClock`),
  在居中内容列里靠左对齐。现在按旧版来:
  - **状态行 = 插件自己的 div**,插进输入框座位(composer stack)第一位 ——
    跟着输入框常驻可见,占真实布局空间(不覆盖对话),插在输入卡片之前;
  - **水平对齐复刻旧版**:量当前会话第一条 flow 项的 x,换算成状态行的左右内边距,
    整行满宽 + 文字从消息列左边界开始(座位外那层 `display:contents` 容器也照顾到了);
  - **样式照抄旧版**:26px 高 / `nowrap` / 自带 shimmer 渐变(插件渐变打开时自动换成
    插件配色)、时钟 13px + caption 色 + 8px 间距、`tabular-nums`;
  - **回合折叠头藏起来**(`display:none`),避免同一状态出现两处;回合结束把状态行撤掉、
    折叠头放出来显示 `Took 12s` / `Worked`;
  - **时长 / 阶段仍从折叠头标签文本读**:React 每秒用 `setTextContent` 整段重写那个标签,
    插件不往标签里塞任何东西,只在旁边读它 —— 时长原样搬进状态行时钟,phase /
    `{elapsed}` / 打字机锁宽照旧;
  - 读屏公告 span(1px 的 `role="status"`,内容仍是 `Deep diving...`)不碰;
  - 0.1.6 及更早的 `role="status"` 状态行本来就在旧位置,只替换文字、不额外插行。

### 兼容性(这一版专门审了一遍)

- **dsh ≤0.1.6(旧宿主)**:状态行本来就是 `role="status"` 那一行,插件只替换它的文字、
  不额外插行 —— 位置改动对它们零影响(回归场景 `old-host`)。
- **dsh 0.1.5-rc.2 的「双结构」**:这一版其实**也有** `button[data-turn-process]`,
  但它的 label 是计数摘要(`6 tool calls` / `思考了一会儿`),不是 `Deep diving...`;
  插件按文案匹配,所以只走旧路径、既不接管也不隐藏那个折叠头(新增回归场景
  `015-coexist` 锁死这一点)。0.1.7-alpha.1 才把 `Deep diving for 12s` 搬进折叠头。
- **降级:找不到输入框座位时不硬来**:折叠头只在「状态行确实插好了」之后才隐藏 ——
  万一输入框座位不存在(布局变了 / 插件跑在非聊天页),宿主的运行中状态照旧可见,
  不会出现「藏了宿主状态、又没插件状态」的空窗(新增回归场景 `no-seat`;
  先藏后找的旧顺序已证实会让该场景变红)。
- **基准失效也有退路**:水平对齐量不到消息列(空会话 / flow 项未渲染)时退回输入卡片,
  取不到就保持上一次的内边距,不抛错。
- **旧配置 / 旧词库 / localStorage / 设置存储**:本次没动配置 schema,冒烟测试
  289 条(含 #51 二次保存回归)全绿。

### 测试

- 真浏览器回归页 `scripts/turn-process-017-test.html` 按新位置重写(夹具复刻
  `#scroll > viewArea + 座位(含 display:contents 容器)` 与折叠头;**8 档场景全部通过**):
  新增断言「状态行插在输入框座位第一位」「在输入卡片之前」「与消息列同一左边界」
  「折叠头被藏起来但仍在被宿主重写」「回合结束撤行 + 恢复折叠头」「旧宿主不额外插行」,
  外加本轮加的两档兼容场景(`015-coexist` 0.1.5 双结构、`no-seat` 座位缺失降级)。
- 纯函数冒烟 289 通过 / 0 失败;既有弹幕 / 布局 / pending 浏览器套件无回归。
- 线上验收(真 dsh 0.1.7 GUI):状态行 `line=[280,740,1113,26]` 在输入卡片
  `card=[462,780,745,36]` 上方、`paddingLeft=198px` 与消息列 `flow.x=478`
  对齐、文案与时长随宿主推进、折叠头隐藏、读屏公告仍是 `Deep diving...`。

## [0.23.6] - 2026-09-22

### 修复

- **修复 dsh 0.1.7 起「替换 deep diving 不生效」**:0.1.7 把回合状态行拆成了两半 ——
  一个 1px 视觉隐藏的 `role="status"` 读屏公告 span(内容仍是 `Deep diving...` /
  `深度求索中`),以及 `button[data-turn-process]` 里真正可见的标签
  (`Deep diving for 12s` / `深度求索中，用时12秒`,时长并进同一段文本)。
  旧逻辑只认 `role="status"`,接管的正是那个隐藏公告:文案确实被替换了,但界面上
  看不见,可见标签原样留着 —— 实测线上 0.1.7 GUI 里就是「1px 的隐藏 span 里躺着
  插件文案、旁边的标签还写着 `Deep diving for 15m 52s`」。现在:
  - **接管按钮本身**:线上实测确认 React 提交阶段对「单个字符串子节点」走的是
    `setTextContent` —— 每秒把标签元素的 `textContent` 整段重写,不是改文本节点的
    `nodeValue`。所以插件自己的 span 不能塞进标签里(会被下一次重写整个抹掉,
    连带时钟一起消失、阶段判定只能一直 thinking)。改为按 `[data-turn-process]`
    定位按钮并接管它:React 的标签元素 `display:none` 藏起来(它继续被每秒重写),
    插件自己的文案 span 与时钟 span 挂在按钮上(React 不认识它们,不会动);
  - **时长照旧**:宿主时长文本原样搬到时钟 span(`12s` / `1分02秒` / `2m 04s`),
    阶段判定、`{elapsed}` 占位符、打字机锁宽都按老路径继续工作;文案字号 / 行高
    对齐 dsh 标签自己的规则(同一组 CSS 变量,跟随「内容字号」设置);
  - **读屏公告不再被改写**:那个 1px 的 `role="status"` 公告 span 直接跳过,
    屏幕阅读器听到的仍是宿主原文;
  - **回合结束自动交还**:宿主把标签写成 `Worked` / `Took 12s` / `Stopped` / `Failed`
    时立刻撤掉插件 span/class 并恢复标签显示,结束文案重新可见;下一次回合开始由
    按钮观察器立刻接管;
  - **阶段分界保持旧版语义**:老宿主的时钟是回合开始 15 秒后才出现的,0.1.7 宿主从一开始
    就把时长写在标签里 —— 新宿主沿用同一 15 秒阈值,`thinking` → `running` 的切换点不变;
    阶段真的变化时(时钟出现 / 跨过 `longAfterMs`)立刻换文案,不等轮换间隔;
  - 0.1.6 及更早的 `role="status"` 状态行、旧配置、词库格式全部零改动兼容。

### 测试

- 纯函数冒烟测试 277 → **289 通过 / 0 失败**:新增 0.1.7 运行中标签前缀解析
  (`resolveDiveDurationPrefix`)、运行中/结束文案归类与时长提取(`matchDiveLabel`)、
  时长文本可被 `parseClock` 解析等 12 条断言。
- 新增真浏览器回归页 `scripts/turn-process-017-test.html` + 运行器
  `scripts/run-turn-process-test.cjs`(6 档场景):复刻 0.1.7 的 DOM 与「宿主每秒
  用 React `setTextContent` 把标签整段重写」的真实行为,断言接管的是按钮、React
  标签被藏起来、文案在宿主重写 ≥2 次后仍在、时钟与宿主一致、`thinking`/`running`/
  `long` 分组正确、回合结束交还宿主,以及旧宿主向后兼容。
- 线上验收(真 dsh 0.1.7 GUI,无头浏览器 + 会话 cookie):插件文案出现在运行中回合的
  状态按钮里、时钟跟随宿主时长推进、读屏公告仍是 `Deep diving...`、
  React 每秒重写后插件 span 与文案都还在。

版本 0.23.5 → 0.23.6

## [0.23.5] - 2026-09-22

### 变更

- **star 词库刷新改为走 PR**:main 已开启 required checks(`test`)并禁止强推 / 删除,直推会被拒绝;
  刷新工作流因此改为「建分支 → 提交 → 开 PR → 显式 dispatch 一次 Test → check 绿了自动合并
  (squash,失败回落 merge)」。
- 一个关键坑:`GITHUB_TOKEN` 建的 PR **不会**触发 `pull_request` 工作流,不显式 dispatch 的话
  `test` 永远不报,required check 会让 PR 永远合不进去 —— 所以 `test.yml` 增加 `workflow_dispatch`,
  `star-pack.yml` 增加 `actions: write` / `pull-requests: write` 权限。
- 规则集生效后不再需要给自动化开 bypass 口子。

版本 0.23.4 → 0.23.5


## [0.23.4] - 2026-09-22

### 变更

- **投稿分支每次从 main 重建**:机器人重跑(例如冲突后重新打标签)时不再复用旧分支,而是
  从当前 main 重新构建并 force 更新 PR 分支 —— 两条投稿同时追加文案时不会再留下需要手工
  解冲突的合并(PR #46 的手工解冲突就是 `config.example.json` 缺逗号、main 连续四次 CI 红的来源)。
  写盘后增加一次 JSON 回读自检,坏文件立刻失败,不带病开 PR。
- `Test` 工作流新增 `merge_group` 触发:仓库启用 merge queue 后,「合并后的结果」会在落地前
  先跑一遍测试,而不是等合并后才发现(需在仓库设置里开启 merge queue)。
- README 补充投稿冲突处理:别手改 `config.example.json`,重新打标签让机器人重建分支。

版本 0.23.3 → 0.23.4

## [0.23.3] - 2026-09-21

### 修复

- **修复「每次更新都重置我设置的」(issue #51)**:设置页保存后,服务端会把整份文档镜像进
  插件目录 `config.json`(兼容旧版本 / 不认设置存储的宿主),而这份镜像又是下一次保存的
  基准层之一 —— 只存「本次差异」时,用户第二次保存(改动即写盘,几乎必然发生)会发现上次的
  设置已在基准里,差异为空,于是那次设置从设置存储里消失;插件升级把 `config.json` 镜像清掉后,
  它就被随包默认值顶回来(例如关掉的弹幕又打开)。现在保存时把**上一次的差异一起并进来**
- **修复 main 上 `config.example.json` 的非法 JSON**:两条投稿(#45 / #47)同时往同一数组末尾
  追加文案,PR #46 的合并(手工解决冲突)丢了逗号,`Test` 从 #139 起连续四次失败(与插件代码
  无关,已发布版本不受影响)。补回逗号后 main 恢复绿灯 —— 机器人写盘用 `JSON.stringify`,
  不会产出这种文本,手改合并冲突后需要重跑校验。
(新的纯函数 `settingsDeltaFor`),设置存储重新成为升级后唯一可信来源。

### 测试

- 纯函数冒烟测试 274 → **277 通过 / 0 失败**:新增 issue #51 回归(二次保存 + 升级删镜像后
  设置仍在)、改回默认值以最新一次为准、自动更新词条依旧不进设置。

版本 0.23.2 → 0.23.3

## [0.23.2] - 2026-09-21

### 变更

- **根治「投稿后 CI 变红」**:新增 `scripts/sync-bank-counts.cjs` —— 从 `config.example.json`
  现算词库规模并写回 README / README_ZH 的文案与词库表、`package.json` 描述、`lib/index.js`
  注释;投稿机器人(`phrase-bot.cjs`)与 star 词库刷新(`update-star-pack.cjs` + `star-pack.yml`)
  改动词库后都会自动调用它 —— 投稿 PR 从此自带同步好的计数,不必再在合并时手改。
- `scripts/smoke-test.cjs` 的两处词库断言不再写死条数,改为与随包 `config.example.json`
  实时对比(「生效文档 == 随包」):投稿、star 刷新、手改词库都不会再让 Test 工作流变红。

### 测试

- 纯函数冒烟测试 270 → **274 通过 / 0 失败**:新增 `bankStats` / `syncTexts` 用例
  (内部自洽、加一条 +1、四文件改写 + 幂等、描述性表格不被误改)。

版本 0.23.1 → 0.23.2


## [0.23.1] - 2026-09-21

### 修复

- **修复 main 上的 Test 工作流**:投稿 #43(PR #44)把随包词库从 1077 加到 **1078 条**
  (`china-ai.zh.running` 末尾新增 1 条),但 `scripts/smoke-test.cjs` 里两处写死的总数断言
  仍是 1077 —— 「真实升级路径」用例与「生效文档仍带完整词库」用例因此失败,PR 的 `pull_request`
  run(#130)与合并后的 `push` run(#131,
  https://github.com/01Virex/dsh-status-rotator/actions/runs/35564650747)都是 **268 通过 / 2 失败**。
  两处断言同步为 **1078**。
- README / README_ZH / `package.json` 描述 / `lib/index.js` 注释里的展示计数一并同步:
  中文 565 → **566**、合计 1077 → **1078**、默认启用 890 → **891**,`china-ai` 行 15 → **16**
(小计 25 → **26**);en 512 与关闭 187 不变。

### 测试

- 纯函数冒烟测试 **270 通过 / 0 失败**(本次只改两处断言的期望值,不新增用例)。

版本 0.23.0 → 0.23.1
## [0.23.0] - 2026-09-21

### 新增

- **炫彩渐变「流动方向」可配**:`gradient` 新增 `direction` —— `rtl`(默认,从右向左,与之前
  完全一致)或 `ltr`(从左向右)。`ltr` 用 `animation-direction: reverse` 倒放同一段循环,首尾
  仍然无缝,流光方向与从左往右的打字机同向(issue #41)。设置页「炫彩渐变」区新增「流动方向」
  下拉,实时预览同步生效。

### 变更

- 渐变注入 CSS 的生成抽成纯函数 `gradientTextCss()`,运行期与测试走同一份实现,不再各写一遍。

### 测试

- 纯函数冒烟测试 262 → **270 通过 / 0 失败**:新增 7 项覆盖方向归一化(非法 / 缺省回落 `rtl`)、
  `rtl` / `ltr` 到 CSS 的映射、非法色值过滤,以及 1 项 node 半区 `sanitizeConfigDocument` 的
  `direction` 白名单。

版本 0.22.0 → 0.23.0

## [0.22.0] - 2026-09-20

### 新增

- **白天 / 黑夜两套渐变配色**:`gradient` 新增 `dayColors`(浅色主题色板,随包默认值在
  `config.example.json` / `config.json`,同色系压暗以保证浅底可读),原 `colors` 语义不变 ——
  即深色主题色板;新增 `mode`:`auto`(默认,跟随 DSH 界面的深浅色自动切换)、`day` / `night`
  (强制其中一套)。设置页「炫彩渐变」区新增「配色模式」下拉与白天 / 黑夜两个色板输入框,
  实时预览与运行时走同一套选色判定。
- **切主题即时换色**:浏览器半区监听 `body[data-ds-dark-theme]` 的增删(DSH ui-layout 切换主题时
  打 / 摘这个属性),主题一变就重算注入的渐变 CSS 并刷新已接管的文字,不用刷新页面。

### 变更

- 设置页渐变配色文案区分白天 / 黑夜;保存校验从「颜色至少 2 个」改为「两套色板各至少 2 个」,
  非法色值仍然当场拦截。
- **老配置行为不变**:没写过 `dayColors`(或只写了 `colors`)的配置,浅色主题仍沿用 `colors`,
  升级不改变既有观感;显式配了 `dayColors` 才启用两套配色。选中的色板配了但非法(< 2 个合法色)
  时仍按老规矩不接管文字(文字是 `color:transparent`,硬接管会直接看不见)。
- node 半区的颜色白名单同步覆盖 `gradient.dayColors` 与 `gradient.mode`(非法 / 未知模式一律剔除,
  老配置不受影响)。

### 测试

- 纯函数冒烟测试 252 → **262 通过 / 0 失败**:新增 10 项覆盖 `normalizeGradientMode`、
  `resolveGradientColors`(自动跟随 / 强制 / 未配色板回退 / 老配置沿用 colors / 非法颜色过滤)、
  `normalizeConfig` 新键归一化,以及 1 项 node 半区 `sanitizeConfigDocument` 的 `mode` /
  `dayColors` 白名单。

版本 0.21.0 → 0.22.0

## [0.21.0] - 2026-09-18

### 新增

- **词库自动更新**:node 半区每 6 小时从上游拉一次词库(默认 `main` 分支的
  `config.example.json`,走 jsDelivr CDN,避开 `raw.githubusercontent.com` 的可达性问题),
  校验后只留 `packs` / `phrases`,**内容真的变了才原子写盘**,并立即在内存生效 —— 合进
  main 的词库投稿、每周自动刷新的 star 包,不用重启、不用重装、也不用重发 npm 包就能到达
  运行中的实例。缓存落在 `$DSH_HOME/status-rotator/bank.remote.json`;
  `DSH_STATUS_ROTATOR_BANK_URL` 可换源或 `off` 关闭,`DSH_STATUS_ROTATOR_BANK_INTERVAL_MS`
  可改间隔或 `0` 关闭(默认 6 小时)。
- **失败保留最后一份好词库**:CDN 不可达 / HTTP 错误 / JSON 非法 / 空文档都只记状态
  (`remoteBankStatus()` 的 `lastError`),正在服务的词库不受影响;离线环境等同于没有这一层。
- **新增 `scripts/verify-bank-auto-update.cjs`**(npm 别名 `npm run verify:bank-auto-update`):
  单进程 + 本地上游,依次 A → B → 500,断言自动更新生效、手写本地词库优先、上游挂掉后
  仍保留最后一份好词库。

### 变更

- 生效文档分层补充为 **内置默认 → 插件目录 `config.json` → 自动更新词库 → 设置存储 →
  本地词库文件**:上游更新只作用于用户没有显式改过的包;设置页改过的包、本地词库文件里
  声明过的包仍然优先。
- 设置页保存的差异基准改为设置层**以下**的全部层(内置 → `config.json` → 自动更新词库):
  自动更新来的词条不会再被一次保存冻结成 `settings.yaml` 里的"用户差异",否则设置层会
  永远压住上游,那个包的自动更新就失效了。
- 自动更新层刻意不带 `config` / `enabledPacks`:上游新增的包会被合并进来,但要等发版
  带上 `enabledPacks` 才会默认启用。

### 测试

- 纯函数冒烟测试 234 → **252 通过 / 0 失败**:新增 18 项覆盖上游地址 / 间隔的默认值与关闭
  开关、缓存路径、`phraseOnlyDocument` 过滤、拉取写盘与 `updates` 计数、内容未变不重复
  写盘、网络失败 / 非 JSON / 空文档 / HTTP 500 一律保留上一次成功词库、五层优先级,以及
  「保存差异不把自动更新词条算成用户改动」。词库条数不变(12 包 **1077** 条)。
- 自动更新关闭或没有网络时,行为与 0.20.0 完全一致(路由测试与热重载验证脚本都显式关闭
  自动更新,保持无网络依赖)。

版本 0.20.0 → 0.21.0

## [0.20.0] - 2026-09-18

### 新增

- **外部词库热重载(不用重发一次 npm 包)**:node 半区新增**包外、可写**的词库层,默认路径
  `$DSH_HOME/status-rotator/phrases.json`,环境变量 `DSH_STATUS_ROTATOR_BANK` 可覆盖(绝对路径
  或相对进程工作目录)。文件与 `config.example.json` 同构,**只写要覆盖的键**即可;每次请求先比
  `mtimeNs` + size、再比内容,变更即重载,浏览器半区在下一次 `reloadIntervalMs` 轮询时拿到新内容
  ——**不重启进程、不重装包**。内置 `config.example.json` 仍是兜底:文件不存在时行为与 0.19.x
  完全一致;文件损坏时保留上一次成功加载的词库并记录错误,不会把线上词库打挂。只取文件里的
  `packs` / `phrases`,其它键(例如 `config`)忽略,运行时选项语义不变。
- **最小可复现验证**:新增 `node scripts/verify-phrase-hot-reload.cjs`(npm 别名
  `npm run verify:bank-hot-reload`)。它在同一个进程里 apply 插件、起一个真实 HTTP server,按
  GET → 写外部词库 → GET → 改写 → GET 验证热重载,全程不重启:server 注册 1 次、词库重载 2 次。
- **词库新增 1 条**:`china-ai` 包 `zh.thinking` 加「正在飞唐杰马…」(与 0.19.3 的
  「正在飞张鹏马…」同系列,中文单语),该分组 14 → **15** 条,总数 1076 → **1077**
  (中 565 / 英 512),README 表格(含 `china-ai` 行与开关合计)、npm 描述同步刷新。

### 变更

- 生效文档的分层顺序补充为 **内置默认 → 插件目录 `config.json` → 设置存储 → 外部词库**;
  外部词库是优先级最高的**词库**层(词库包按 `id` 逐条合并,只声明一个包不影响其余 11 个),
  没有该文件时分层与 0.19.x 完全相同。

### 测试

- 纯函数冒烟测试 224 → **234 通过 / 0 失败**:新增 10 项覆盖外部词库路径解析(`$DSH_HOME` /
  环境变量覆盖)、文件不存在时的内置兜底、变更检测(`mtimeNs` + size 快速路径 + 内容比对)、
  `reloads` 计数、损坏文件保留上一次成功值并记录 error、只认 `packs` / `phrases`,
  以及「外部词库覆盖设置层同名包、未声明的包原样保留」;两处词库计数断言同步为 **1077**。
- `node scripts/check-bank-memes.mjs` 审计确认新条目无重复、省略号合规、未新增超长告警
  (48 条既有超长告警与本次无关)。

版本 0.19.3 → 0.20.0

## [0.19.3] - 2026-09-18

### 变更

- **词库新增 2 条**:`china-ai` 包 `zh.thinking` 加「正在卸载偷数据的ZCode…」与「正在飞张鹏马…」(围绕
  智谱 ZCode 被曝静默上传全量 Git 历史的争议),该分组 7 → **9** 条;两条均为中文单语,总数
  1074 → **1076**(中 564 / 英 512),README 表格(含 `china-ai` 行与开关合计)、npm 描述同步刷新。

### 测试

- 纯函数冒烟测试 **224 通过 / 0 失败**:词库计数断言(生效文档「12 包 N 条」两处)随新词条同步为
  **1076**;`node scripts/check-bank-memes.mjs` 审计确认新条目无重复、无缺省略号、未新增超长告警
  (48 条既有超长告警与本次无关)。

## [0.19.2] - 2026-09-16

### 修复

- **0.19.1 的自动收敛在真实升级路径上是空转**:随包词库自己会随版本变化(0.19.1 就给 `deepseek` 加过
  词条、star 包换过排版),而 `deltaOf` 对数组是「整体替换」——老安装存在设置里的整份词库于是处处
  「不相等」,又被整份写回。真机实测:收敛前 `status-rotator` section 82,966 B,收敛后 81,926 B。
  现在收敛前会再过一遍新增的 `pruneShippedBloat`:这条词条随包词库里到底有没有?有 → 那是旧版随包
  数据,不算用户改动。同一份真机数据现在收敛到 **1,586 B**,生效文档词条 **零丢失**(老库里有 30 条
  随包没有的大小写变体,原样留成残差;用户改过的 `danmaku.intervalMs/opacity/maxCount` 与 `pill` 全在)。
  干净的 0.19.0 老安装整库:55,395 B → **37 B**(0.19.1 是 3,939 B)。
- **设置页保存会把整份词库再写回存储**:浏览器提交的是完整文档,只要有一个包被动过,「数组整体替换」
  就会让 12 个包整份进 `settings.yaml`。`deltaOf` / `mergeLayers` 现在对「元素都是带唯一 `id` 的普通
  对象」的数组按 id 逐条递归(与 dsh-settings 的对象合并同口径):只有动过的那条进存储,其余包不受
  影响;user 删掉的条目写成 `$deleted` 墓碑,合并时真删,不会被 base 顶回来。没有唯一 id 的数组
  (`enabledPacks` / `schedule`)仍然是整体替换。
- **一次性收敛不再写删除墓碑**:老安装的整库里没有某个包,只说明「那个包当时还没发布」,不是用户删的,
  收敛时不会顺手把后来新增的包删掉。

### 变更

- **设置标记升到 `settingsVersion: 2`**:0.19.1 已经写过的 section(标记为 1)会再收敛一次,之后幂等。

### 测试

- 纯函数冒烟测试 212 → **224 通过 / 0 失败**:新增 keyed 数组的差异 / 合并 / 墓碑 / 顺序 / 无 id 数组仍
  整体替换 / base 里没有该数组时墓碑不漏进生效文档、`pruneShippedBloat` 的五类判据(旧版随包数据剔空、
  用户词条与自建包保留、遗留单体词库只留残差、空壳包不留 `packs` 键),以及「真实升级路径:老库少一条 +
  用户调过开关 → 收敛成 <400 B 且生效文档仍是 12 包 1074 条」。

## [0.19.1] - 2026-09-16

### 修复

- **装载不再把整份词库塞进 `$DSH_HOME/settings.yaml`**:设置命名空间原先按顶层键整份覆盖,
  而保存/迁移提交上来的文档永远带着完整词库(12 个包 / 1074 条),于是每次装载、每次保存都把
  这份文档序列化进设置存储。默认词库现在只留在包内的 `config.example.json`,设置命名空间里
  只写**与它不同的那部分**;生效文档装载时按 **内置默认 → 插件目录 `config.json` → 设置存储**
  合并,词库与既有功能不受影响。
- **老安装的臃肿设置会自动收敛**:已经被旧版本写进设置存储的整份词库,在首次启动时一次性
  收敛成差异(幂等,之后不再改写)。用仓库里的复现脚本在临时 `$DSH_HOME` 上跑真实设置
  provider:播种旧安装的整份词库后,`settings.yaml` **55,394 B / 1306 行 → 68 B / 5 行**
  (该 section 58,777 B → 68 B),用户的改动(如 `intervalMs`)原样保留。

### 变更

- **设置文档的分层合并改为对象递归、数组整体替换**(与 dsh-settings 同口径):只有这样才能
  「只存差异」而仍还原出完整文档,`mergeDocuments(bundled, deltaOf(bundled, doc))` 与 `doc` 等价。
- **词库新增 1 条**:`deepseek` 包 `zh.thinking` 加「正在往Deepseek Harness文件里塞1000+行屎…」,
  总数 1073 → **1074**(中 562 / 英 512),README 表格、npm 描述同步。

### 测试

- 纯函数冒烟测试 199 → **212 通过 / 0 失败**:新增 `deltaOf` / `mergeLayers` / `deepEqualJson` /
  `contentTypeOf` 的差异计算、数组整体替换、往返等价、标记键不外泄,以及「生效文档仍带完整词库
  (12 包 1074 条)」。

## [0.19.0] - 2026-09-15

### 新增

- **顶部 / 底部弹幕(bilibili 风格)**:`danmaku.types` 三种类型(滚动 / 顶部 / 底部)按权重分发。顶部
  水平居中、后到的自上而下堆叠;底部水平居中、后到的自下而上堆叠;两者固定不动,到 `durationMs`
  整条消失。类型标识接受 `scroll` / `top` / `bottom` 或 bilibili 弹幕协议的 `1` / `4` / `5`;
  `danmaku.mode` 可强制只发某一种。滚动弹幕的代码路径与行为不变。
- **弹幕前层**:顶部 / 底部弹幕进独立前层,用正 `z-index`(默认 10)压在聊天内容之上,不再被消息
  气泡盖住;滚动弹幕仍在界面后面。dsh 外壳 overlay 层是 20、侧栏拖拽手柄 11,所以默认值既压得住
  聊天、又不会糊住设置弹窗;层级由 `danmaku.fixed.zIndex` 控制,设负数即塞回界面后面。
- **设置页新增弹幕类型与样式分组**:三种类型的开关与权重、强制类型下拉、顶部 / 底部样式(字号 / 颜色 /
  描边 / 边距 / 间距 / 停留时长 / 同屏上限 / 层级),以及两个行为开关;实时预览同时渲染一条顶部、
  一条底部弹幕。

### 变更

- **顶部 / 底部弹幕跟随炫彩开关**:`rainbow` 开启时与滚动弹幕共用 `colors` 色板逐颗随机取色,关闭时
  才用 `fixed.color`(默认白字)。
- **固定弹幕改用「车道」堆叠**:每条占一条空闲车道,旧的消失后车道立刻回收,不再出现「按在途高度
  累加」在中间那条提前消失时把两条弹幕叠在同一行的问题。
- **滚动弹幕避开顶部 / 底部弹幕占用的竖直带**(`fixed.reserveBands`,默认开):滚动文案不再从固定
  弹幕后面穿过;关掉即回到旧的随机落点。滚动弹幕的落点参照同时从视口高度改为弹幕层高度,和固定
  弹幕车道用同一套坐标;窗口太矮、区间被挤没时自动退回旧行为,弹幕不会消失。
- **底部弹幕贴住输入区上沿**(`fixed.anchorBottomToHost`,默认开):dsh 状态行就在输入区最上面,
  半透明弹幕压在上面时它的 shimmer 会从弹幕里透出来、看着像「特效映射到了弹幕上」;现在底边按状态行
  的位置算,量不到状态行时回落到 `marginBottom`。

### 修复

- **弹幕文字不受宿主文字特效影响**:每条弹幕显式压掉 `-webkit-text-fill-color` /
  `-webkit-text-stroke` / `animation`,外来的透明填充或动画不会渗到弹幕文字上。
- **node 半区不再丢弹幕新字段**:`sanitizeConfig` 重建 `fixed` 时会把 `zIndex` / `reserveBands` /
  `anchorBottomToHost` 一并保留,设置页保存后开关不会静默丢失。

### 测试

- 纯函数冒烟测试 178 → 199:新增 `danmakuFreeLane` / `danmakuLaneOffset` / `danmakuScrollBand` /
  `pickDanmakuMode` / `normalizeDanmakuMode` / `isSafeShadow`,以及 `mode` / `types` / `fixed` 的
  解析、钳制与向后兼容(node 半区写入侧同口径)。
- 真浏览器回归页新增两档弹幕场景(`?modes=1` 与 `?modes=1&rainbow=1`):居中、车道堆叠与回收、
  同屏不重叠、滚动弹幕不与固定带交叠、命中测试证明固定弹幕不被消息盖住、炫彩取自色板。

## [0.18.0] - 2026-09-15

### 新增

- **设置页补齐预设管理**:可直接新建、就地改名、删除预设;删除时同步清理引用它的调度规则与
  `activePreset`,不必再手改 `config.json` 才能造预设。
- **数值字段即时校验与「恢复默认」**:范围与 node half 的 `CONFIG_LIMITS` / `DANMAKU_LIMITS`
  同口径(`CONFIG_RANGES` / `DANMAKU_RANGES`),越界或非数字当场标红;值偏离默认时出现恢复按钮。

### 变更

- **调度规则改成卡片**:一条规则一张卡,预设下拉、星期药丸、起止时间与删除按钮全部收在同一行
  (原先控件会换行散落);没有规则时显示空状态提示。时间输入加宽到能完整显示 `09:00`。
- **保存改为「改动即写盘」,去掉「保存词库」按钮**:开关与下拉一改即写,文本和数值输入停顿
  400ms 自动写盘(预设改名在失焦时写盘);写盘走串行队列、按操作顺序落盘,乐观更新让界面立刻
  反映。正常状态下不显示任何保存提示(没有「保存中」「已保存」「改动即保存」这些字样),
  只有写盘失败才在工具栏标红;编辑器不再有「未保存」这一状态,失败时改动留在原地、下次改动
  自动重试(不会原地刷屏重试)。
- **设置页按语义归为四个 tab**:文案 / 外观 / 行为 / 自动化。原先九个分组竖排一页,决定文案写进
  哪里的「词库包」被排在「基本设置」之后 —— 现在编辑目标、词库、词库包、预设同处一页。
- **两个编辑目标下拉合并为一个「编辑目标」**:基础词库 / `preset:<id>` / `pack:<id>` 三选一,
  写入位置与界面所选目标一致(旧实现里预设与词库包各有一个下拉,而保存只写其中一个);
  目标失效(预设或包被删)时自动退回基础词库。
- **设置页排版对齐官方插件设置页**(`dsh-client-ui-settings-plugins`):760 列、18/600 标题、
  13/500 字段标签、输入框 h34 / `.5px` `border-l4` / `bg-layer-3` / 13px、`.5px` hairline 分隔、
  次级动作改无边框文本按钮;select 箭头改纯 CSS 折线(不再写死 `#81858C`);清掉无消费者的
  死规则(`.dsh-sr-btn-sm` / `.dsh-sr-phasehead` / `.dsh-sr-btn-primary` / `.dsh-sr-dirty` / `.dsh-sr-ok`)。

### 修复

- **定时规则不再能加成无效规则**:没有预设时「添加规则」置灰并提示先去「文案」页新建预设
  (此前点一下就会造出一条绑不到预设的规则,紧接着报「调度规则无效」);规则的目标下拉不再提供
  「默认(基础词库)」这个不合法选项,指向已删预设的旧规则显示「请选择预设」而不是错的预设名。
- **切编辑目标/预设不再静默丢草稿**:切换目标或「重读」会先把当前草稿落盘再动作,不再需要确认
  弹窗,也不会出现「改了没保存就走人」的情况。
- **锁定态补全**:保存进行中,三阶段文本框与 zh/en 语言 tab 此前仍可编辑(已补 `disabled`)。
- **调度规则校验预设存在性**:指向不存在预设的规则保存时直接报错,不再留下永不命中的规则。
- **英文 `fontWeight.invalid` 文案多一层转义**:界面曾显示字面 `\"inherit\"`,现在正常显示。

### 说明

- 本次发布合并 [mrbbbaixue](https://github.com/mrbbbaixue) 的 **PR #38**:设置页从「九个分组竖排一页」
  重排为**文案 / 外观 / 行为 / 自动化四个 tab**,「预设」与「词库包」两个各自独立的编辑目标下拉合并为
  一个「编辑目标」,排版对齐官方插件设置页(`dsh-client-ui-settings-plugins`),「保存词库」按钮换成
  **改动即写盘**。改动全部落在 `lib/client.js`(981 行改动,+623 / −358),node 半区与配置结构零改动,
  `config.json` 无需迁移。
- **npm 包首次带上 v0.17.3 的修复**:0.17.3 只发了 GitHub Release,npm 上的 `latest` 一直停在 0.17.2 ——
  所以从 npm 升级的人这一次同时拿到 0.17.3 + 0.18.0 两版内容(`{pending}` 不再恒为 `0`,实时占位符
  在取值变化的当下重渲染)。
- 词库随本次发版刷新:`star-route` 随星标名单 77 → **82** 位,总数 1063 → **1073**(中 561 / 英 512),
  npm 描述与中英文 README 表格同步。
- 回归情况:`npm test` **178 通过 / 0 失败**;真浏览器三页回归(`npm run test:browser`)全绿 ——
  弹幕挂载四档时序、标签排版三例、`{pending}` 实时刷新与无 `uiSession` 兜底。
- 贡献者统计随本次发版重新同步(139 → **145** commits,2026-09-15):`mrbbbaixue` 3 → 4(PR #38)、
  仓库账号 19 → 20、机器人 53 → 57;`CONTRIBUTORS.md` / `CONTRIBUTORS_ZH.md` 补上 PR #38 记录。
- 升级后**重启一次 `dsh web`**,再打开「设置 → 状态文案」即可看到新排版。

## [0.17.3] - 2026-09-14

### 修复

- **`{pending}` 恒为 0 修好了**:旧实现读会话快照的 `pending` 字段,而 dsh 0.1.5 的
  `SessionSnapshot` 已经没有这个字段(没有任何写入方),所以这个占位符一直硬编码输出 `0`。
  现在改读 `ctx.uiSession.pendingInteractions` —— 待作答交互的真实来源。**注意它是
  `HostObservable`(取 `getSnapshot()` 才是「SessionId → 交互」的表)**:直接对它取
  `entries` 会数到它自己的方法名,第一版改动就在这里又踩了一次。
- **实时字段不再等下一次轮换**:`setLive()` 的监听者集合此前是空的 —— 唯一的订阅者随
  v0.15.0 的悬浮 Pill 一起下线了,`{pending}` 这类事件驱动的值只能等下一次轮换才被画出来。
  现在由 `setLive()` 自己按微任务合并调度重渲染,并新增原始模板表(`liveTemplates`):
  已接管文案里的占位符已经被插值过,必须靠原始模板才能重渲染,否则等于把插值结果再插值
  一次(数值永远不变)。

### 变更

- 合并 [mrbbbaixue](https://github.com/mrbbbaixue) 的 **PR #37**:删除 v0.15.0 起以注释形式
  保留的悬浮状态 Pill 代码(`lib/client.js` 净减 160 余行,含默认配置块、归一化、中英文案、
  设置页表单、`.dsh-sr-pill*` 样式与 `shell.overlay` 注册),中英文档里的「悬浮状态 Pill
  (已下线)」小节同时移除。随 Pill 一起失去订阅者的 `liveListeners` / `subscribeLive` 机制
  也一并退役 —— `{pending}` 的重渲染由 `setLive()` 直接调度(见上)。

### 说明

- **审批策略的差异现在真的会体现在文案里**:`ask` 下审批面板等待期间 `{pending}` = 1;
  `never` 下 dsh 在派发审批瀑布前就直接判拒、客户端不建面板,所以审批贡献 0(被拒绝不是
  「待作答」),而提问与策略无关、照样计数。插件本身不读也不改权限预设。这条差异是本轮
  改动的起因,已写进中英文文档与 `pendingCountOf` 的注释。
- 新增真浏览器回归页 `scripts/live-pending-test.html`:真插件跑 pending `0 → 1 → 0 → 1`,
  外加无 `uiSession` 服务时的兜底;`npm run test:browser` 现在会跑三页,单跑用
  `npm run test:browser:pending`。
- `npm test` 新增 8 条纯函数断言,当前 **178 通过 / 0 失败**:计数语义、会话隔离、
  `null`/`undefined` 值、非 map 输入与抛错兜底、数字/字符串会话 id、`{pending}` 字符串化。
- 贡献者统计随本次发版重新同步(133 → **139** commits,2026-09-14):`mrbbbaixue` 2 → 3
  (PR #37)、仓库账号 18 → 19、机器人 49 → 53;`CONTRIBUTORS.md` / `CONTRIBUTORS_ZH.md`
  补上 PR #37 与重新同步的 API 方法。
- `scripts/package-release.cjs` 的文件清单与 `package.json` 的 `files` 对齐:补上
  `lib/index.d.ts`(此前解压安装的产物缺类型入口)与 `CHANGELOG.md`。

## [0.17.2] - 2026-09-09

### 新增

- 补齐 `lib/index.d.ts` 类型声明与 `types` 字段(node 半区公开面;上下文用最小结构描述,
  不强制依赖 `@deepseek-ai/cordis` 的类型)。
- `exports` 增加 `types` 条件,并显式声明 `peerDependencies`(`@deepseek-ai/cordis`,
  标记为 optional —— 宿主已自带,单独装本插件时不会被强行拉下来)。
- `files` 改为逐文件列出(`lib/index.js` / `lib/client.js` / `lib/index.d.ts`),
  发布产物覆盖更明确。
- 新增 `Plugin QC` 工作流:每次 push / PR 用 [dsh-qc](https://github.com/Herdeny/dsh-qc)
  跑静态 + 动态质检,评分与证据链打到日志里(失败不阻断 CI)。

### 说明

- 起因是把插件放进 awesome 榜单时发现没有可引用的质检分;本地 `dsh-qc report` 由 52/100
  提升到 62/100(清单协议项由 5 通过/3 失败变为 8 通过/0 失败),动态验证交给 CI 在 Linux 上跑。

## [0.17.1] - 2026-09-09

### 变更

- `star-route` 词库包随星标名单刷新:75 → **77** 位(新增 `ippdesu`、`monkeycathyd`),
  词库总数 1059 → **1063**(中 556 / 英 507),README 表格与 npm 描述同步。
- 贡献者统计同步到 GitHub API 最新值(133 commits)。

### 说明

- 纯词库/文档补丁,插件代码零改动;升级后重启一次 `dsh web` 让 node 半区重新读配置即可。

## [0.17.0] - 2026-09-09

### 安全

- **配置写接口补上来源栅栏**:之前 `PUT/POST /plugins/dsh-status-rotator/config.json` 没有任何校验,
  任意网页都能用跨站简单请求(`content-type: text/plain`,不触发预检)改写你的本地配置。
  现在只接受 `application/json` + 同源请求(`Origin` 必须与 `Host` 一致、`sec-fetch-site` 只允许
  `same-origin`/`none`),跨站请求一律 403;读取接口也挡掉 `cross-site`。
- **颜色白名单**:渐变/弹幕颜色会被拼进注入的 `<style>`,现在只接受 `#rrggbb` / `rgb()` / `hsl()` /
  CSS 颜色名,含 `;` `{` `url(` 之类的值直接丢弃 —— 既挡 CSS 注入,也避免一个错色值让整条
  `background-image` 失效。
- **数值钳制**:服务端保存与客户端加载都按同一张表钳制(`intervalMs ≥ 250`、`typeSpeedMs ≤ 1000`、
  弹幕 `intervalMs ≥ 200`、`maxCount ≤ 60`、`zIndex` 收敛等)。此前 `intervalMs: 1` 会让页面
  每秒重建上千次定时器。

### 修复

- 修复路由 disposer 泄漏:正常路径(webServer 已就绪)返回的清理函数是空的,插件重载/二次
  apply 时宿主对重复路由抛 `duplicate exact route`,激活直接失败。
- 渐变配色非法时不再接管文字:以前会写出一条被浏览器丢弃的 `background-image`,而文字是
  `color: transparent` —— 状态行会整条消失;现在回退宿主自带的 shimmer 渐变,并在设置页标红。
- 打字机锁宽:逐字输出期间用整句像素宽度锁住宿主 `min-width`,紧跟其后的时钟不再左右跳。
- 长文案不再撑出横向滚动条:宿主 `.turnStatus` 是 `26px + white-space: nowrap`,超长文案会把
  滚动容器顶出横向滚动条;现在文本盒收窄,真溢出时右侧做淡出,时钟保持可见。
- 渐变生效时关掉宿主自带的 1.8s shimmer,不再两层流光互相打架。

### 变更

- 设置页顺序调整:**实时预览**置顶,**文案词库**从最后一位提到第二位;新增预览卡片(按当前
  草稿实时渲染状态行与弹幕条)——官方设置弹窗是全屏遮罩,以前只能"改→保存→关弹窗→看"。
- 颜色序列输入支持 `rgb(255, 0, 0)` 这类带括号的写法(此前按逗号切分会被拆碎),非法 token
  在输入框标红、保存时拦下并列出。

### 文档

- README 首屏重写:去掉版本变更横幅与求 star 钩子,改为「一句话定位 → 30 秒上手 →
  功能一览」,版本史移入本文件。
- 新增本文件 `CHANGELOG.md`,版本变更不再堆在 README 顶部。
- 修正 Release 安装说明:产物是 `dsh-status-rotator-<tag>.zip`(解压即用目录),不是 npm tarball。
- `star-route` 词库包文案空格归一:此前按名字长度分三档(短名不加空格),同一份词库里
  「正在路由01Virex写代码…」与「正在路由 1251639747jm-ctrl 写代码…」混排,现在统一为
  「正在路由 <login> 写代码…」;长度上限对该包单独放宽(名字是数据,不套人工文案规范)。

### 工程

- 新增 `scripts/label-layout-test.html`(真浏览器布局回归:锁宽/截断/配色回退/设置页渲染),
  `scripts/run-danmaku-mount-test.cjs` 支持 `--page=label`,并改用 `--remote-debugging-port=0`
  (固定端口段在部分 Windows 上落在 Hyper-V 保留区,`bind()` 会失败)。
- 冒烟测试 151 → 170 条断言:新增配置栅栏、数值钳制、颜色白名单、路由卸载回归。

## [0.16.2] - 2026-09-08

### 文档

- 版本横幅与词库统计同步(纯文档补丁,代码零改动)。

## [0.16.1] - 2026-09-08

### 修复

- **弹幕恢复可见**:弹幕层改为挂进「画界面底色的元素」,此前被会话面板自己的不透明底色整块盖住。
- **设置层恢复生效**:新版 `@deepseek-ai/dsh-settings` 不再导出 `settingsNamespace()`,旧调用抛错
  又被外层 `catch` 吞掉,导致保存的设置一直静默失效(不生效、也不落盘)。

## [0.16.0] - 2026-09-08

### 变更

- `star` 词库包拆成两个:纯求 star 的 `star-ask` 与星标者点名的 `star-route`,且**默认关闭**。
- 设置页底部新增仓库链接;新增 `Star packs` 工作流,每周用仓库 `GITHUB_TOKEN` 刷新星标名单。

## [0.15.2] - 2026-09-08

### 修复

- 修复弹幕可能永久不可见:客户端半区早于外壳渲染时退回 `body` 且沿用 `z-index: -1` 且不再重试;
  现在挂载点每拍重解析,并新增真浏览器回归页。

## [0.15.1] - 2026-09-08

### 新增

- 新增 star 词库包(求 star 文案 + 69 位星标者路由文案),词库 886 → 1047 条,10 → 11 包。

## [0.15.0] - 2026-09-07

### 变更

- 悬浮状态 Pill 下线(代码注释保留,可恢复);词库质检脚本修复空核心词库崩溃。

## [0.14.2] - 2026-09-07

### 修复

- 修复中文界面状态标签延迟替换:适配 DSH 本地化文案(`深度求索中...`),状态文字现在立即替换。

## [0.14.1] - 2026-09-06

### 修复

- 设置页词库包 UX:未配置 `enabledPacks` 时显示为全部启用;全开保存不写字段(避免误写 `[]`
  清空词库);默认词库为空时自动选中第一个包;提示改大白话。

## [0.14.0] - 2026-09-06

### 新增

- 词库包模块化:十大主题包(DeepSeek / 西方 AI / 中国 AI / 写代码 / 反代 / 系统管理 / 数理 /
  摸鱼 / 网络梗 / 日常),投稿机器人支持指定目标包。

## [0.13.0] - 2026-09-06

### 新增

- 梗词库扩充(批次 1–5)与社区投稿入库(PR #16/#18/#20/#23/#25/#26/#28)。

## [0.12.0] - 2026-09-06

### 新增

- 加权随机文案选择:文案可写成 `{ "text": "…", "weight": 3 }`,按权重比例抽取。

## [0.11.0] - 2026-09-04

### 变更

- 设置页按 DSH 官方设置页风格重排控件与排版。

## [0.10.0] - 2026-08-30

### 新增

- 词库投稿机器人:Issue 表单一键投稿,自动校验/查重/归一化并开合并 PR;合并后自动删分支、关 Issue。
- 字体粗细可调 `fontWeight`:状态文字与弹幕统一生效,设置页新增下拉。

## [0.9.1] - 2026-08-27

### 变更

- npm 搜索可见性:扩充 keywords / description(danmaku / bilibili / typewriter / rainbow 等)。

## [0.9.0] - 2026-08-27

### 新增

- 弹幕模式:所有文案随机以视频网站弹幕形式在界面后面飘过(炫彩、随机大小、透明度、频率可配)。

## [0.8.0] - 2026-08-27

### 变更

- 开发脚本(`scripts/`、`gen-config.cjs`)移出 npm 发布集,降低静态扫描面。

## [0.7.1] - 2026-08-24

### 修复

- 修复 0.7.0 的省略号规范化脚本误伤 `config` 字段(渐变颜色/标题模板被追加省略号导致渐变失效)。

## [0.7.0] - 2026-08-24

### 变更

- 默认词库省略号全量统一(所有文案以 `…` 结尾);npm dist-tag 标记 `stable`。

## [0.6.6] - 2026-08-21

### 文档

- npm README 与 GitHub 对齐;省略号与 Pill 模板文案统一。

## [0.6.5] - 2026-08-21

### 修复

- 状态 Pill 的阶段/时长改为会话快照优先,模型名走官方 `modelDirectories`;默认模板四字段。

## [0.6.4] - 2026-08-21

### 修复

- 修复 webServer / settings 就绪时序:插件在 `inject = []` 下提前激活导致路由未注册、配置 404。

## [0.6.3] - 2026-08-21

### 修复

- React 重渲染时立即重新接管状态行,修复文案与时钟闪烁。

## [0.6.2] - 2026-08-21

### 修复

- webServer 改为可选加载,没有 Web UI 的宿主也能激活插件。

## [0.6.1] - 2026-08-21

### 修复

- 设置持久化到 dsh 官方设置存储(`$DSH_HOME/settings.yaml`),升级不再丢配置;设置页新增渐变编辑器。

## [0.6.0] - 2026-08-21

### 新增

- 实时状态引擎 + 悬浮状态 Pill(后者已在 0.15.0 下线)。

## [0.5.1] - 2026-08-21

### 工程

- README 徽章与安装命令前置;新增 CI 测试工作流。

## [0.5.0] - 2026-08-21

### 新增

- 模板占位符(`{elapsed}` / `{phase}` / `{date}` …)、浏览器标签页标题轮换、预设与时段调度。

## [0.4.0] - 2026-08-19

### 变更

- 词库按阶段重新分布(running / long);扩充 thinking 中英词库并补全翻译。

## [0.3.0] - 2026-08-18

### 文档

- 文档中英双语化,安装步骤前置,npm 发布配置。

## [0.2.0] - 2026-08-14

### 工程

- 发布基础设施:CI 打包 + 版本号;声明 `dsh.bundle` manifest,支持 `dsh plugin add` 安装。

## [0.1.0] - 2026-08-14

### 新增

- 首个版本:把 DSH Web 回合状态文字替换成自定义文案库(阶段感知、打字机、定时轮换、
  按 `role="status"` + `aria-live="polite"` 零侵入定位),文案与代码分离。

[0.34.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.34.0...v0.34.1
[0.34.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.33.2...v0.34.0
[0.33.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.33.1...v0.33.2
[0.33.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.33.0...v0.33.1
[0.33.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.32.0...v0.33.0
[0.32.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.31.0...v0.32.0
[0.31.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.30.4...v0.31.0
[0.30.4]: https://github.com/01Virex/dsh-status-rotator/compare/v0.30.3...v0.30.4
[0.30.3]: https://github.com/01Virex/dsh-status-rotator/compare/v0.30.2...v0.30.3
[0.30.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.30.1...v0.30.2
[0.30.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.30.0...v0.30.1
[0.30.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.29.0...v0.30.0
[0.29.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.28.0...v0.29.0
[0.28.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.27.5...v0.28.0
[0.27.5]: https://github.com/01Virex/dsh-status-rotator/compare/v0.27.4...v0.27.5
[0.27.4]: https://github.com/01Virex/dsh-status-rotator/compare/v0.27.3...v0.27.4
[0.27.3]: https://github.com/01Virex/dsh-status-rotator/compare/v0.27.2...v0.27.3
[0.27.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.27.1...v0.27.2
[0.27.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.27.0...v0.27.1
[0.27.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.26.1...v0.27.0
[0.26.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.26.0...v0.26.1
[0.26.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.25.0...v0.26.0
[0.25.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.24.0...v0.25.0
[0.24.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.23.6...v0.24.0
[0.23.6]: https://github.com/01Virex/dsh-status-rotator/compare/v0.23.5...v0.23.6
[0.23.5]: https://github.com/01Virex/dsh-status-rotator/compare/v0.23.3...v0.23.5
[0.23.4]: https://www.npmjs.com/package/dsh-status-rotator/v/0.23.4
[0.23.3]: https://github.com/01Virex/dsh-status-rotator/compare/v0.23.0...v0.23.3
[0.23.2]: https://www.npmjs.com/package/dsh-status-rotator/v/0.23.2
[0.23.1]: https://www.npmjs.com/package/dsh-status-rotator/v/0.23.1
[0.23.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.22.0...v0.23.0
[0.22.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.21.0...v0.22.0
[0.21.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.20.0...v0.21.0
[0.20.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.19.3...v0.20.0
[0.19.3]: https://github.com/01Virex/dsh-status-rotator/compare/v0.19.2...v0.19.3
[0.19.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.19.1...v0.19.2
[0.19.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.19.0...v0.19.1
[0.19.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.18.0...v0.19.0
[0.18.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.17.3...v0.18.0
[0.17.3]: https://github.com/01Virex/dsh-status-rotator/compare/v0.17.2...v0.17.3
[0.17.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.17.1...v0.17.2
[0.17.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.17.0...v0.17.1
[0.17.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.16.2...v0.17.0
[0.16.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.16.1...v0.16.2
[0.16.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.16.0...v0.16.1
[0.16.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.15.2...v0.16.0
[0.15.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.15.1...v0.15.2
[0.15.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.15.0...v0.15.1
[0.15.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.14.2...v0.15.0
[0.14.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.14.1...v0.14.2
[0.14.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.14.0...v0.14.1
[0.14.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.13.0...v0.14.0
[0.13.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.12.0...v0.13.0
[0.12.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.10.0...v0.11.0
[0.10.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.9.1...v0.10.0
[0.9.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.8.0...v0.9.0
[0.8.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.7.1...v0.8.0
[0.7.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.7.0...v0.7.1
[0.7.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.6.6...v0.7.0
[0.6.6]: https://github.com/01Virex/dsh-status-rotator/compare/v0.6.5...v0.6.6
[0.6.5]: https://github.com/01Virex/dsh-status-rotator/compare/v0.6.4...v0.6.5
[0.6.4]: https://github.com/01Virex/dsh-status-rotator/compare/v0.6.3...v0.6.4
[0.6.3]: https://github.com/01Virex/dsh-status-rotator/compare/v0.6.2...v0.6.3
[0.6.2]: https://github.com/01Virex/dsh-status-rotator/compare/v0.6.1...v0.6.2
[0.6.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.5.1...v0.6.0
[0.5.1]: https://github.com/01Virex/dsh-status-rotator/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/01Virex/dsh-status-rotator/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/01Virex/dsh-status-rotator/releases/tag/v0.1.0
