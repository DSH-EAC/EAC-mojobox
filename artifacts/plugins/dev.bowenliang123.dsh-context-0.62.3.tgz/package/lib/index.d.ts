import { z } from "zod";
import "@deepseek-ai/dsh-session";
import z$1 from "@deepseek-ai/schemastery";
import { Context } from "@deepseek-ai/cordis";
//#region src/host/activity.d.ts
/** The persisted fold state (the registry's `stateSchema` contract). */
interface ActivityState {
  days: Record<string, {
    tokens: number;
    requests: number;
    cost?: SessionCostUsage;
  }>;
  /** The route in force (last `request/header`'s config wins) — prices each settlement. */
  model?: string;
  provider?: string;
  /** The open step's start instant (armed by `step/start`, cleared by `step/end`). */
  stepStart?: number;
}
//#endregion
//#region src/host/headers.d.ts
/**
 * One stored tool: the v1 row shape carried the producer description and the
 * raw schema; folds since the #37 slim-down append metadata-only entries.
 */
interface StoredHeaderTool {
  name: string;
  tokens: number;
  description?: string;
  plugin?: string;
  schema?: unknown;
}
/** One stored epoch: v1 rows carried `system`; folds since carry `systemTokens`. */
interface StoredHeaderRecord {
  seq: number;
  time: number;
  system?: string;
  systemTokens?: number;
  tools: StoredHeaderTool[];
}
interface HeadersState {
  headers: StoredHeaderRecord[];
}
//#endregion
//#region src/host/fold.d.ts
/**
 * History retention bounds (configurable since 0.11 — see config.ts; these
 * are the defaults' values). The fold keeps per-STEP request records; once the
 * newest run count exceeds `maxKeptTurns`, the timeline is trimmed to the
 * most recent whole TURN runs (never cutting a turn in half), so turn
 * granularity can always show the full recent turn range instead of a
 * step-count fragment. The turn-run trim runs whenever the cap is crossed
 * (not only when the raw step bound is), so the bounded state stays at the
 * newest ~`maxKeptTurns` turns deterministically as a live log grows.
 */
interface TimelineState {
  /** Model-visible surface, newest last. */
  surface: SurfaceNode[];
  sums: Record<Category, number>;
  systemTokens: number;
  /**
   * The live system-prompt nodes, oldest first — a log's `system/message`
   * surface nodes. `systemTokens` is the LAST entry with tokens > 0 (the
   * harness's own "last nonempty surviving system" rule), so an empty dormant
   * node keeps its position without clearing the prompt. Bounded by
   * SYSTEM_NODES_MAX. ABSENT on rows folded before this field existed — the
   * wire then serves no `systems` and the client falls back to the header
   * epoch's own envelope figure.
   */
  systems?: SystemPromptNode[];
  toolsTokens: number;
  /**
   * The projection-cache precondition is plain JSON: a property whose value
   * is `undefined` makes the whole checkpoint unserializable
   * (`snapshotJsonValue` rejects it), which fails EVERY cache write for the
   * session — including the `title` projection row that powers the session
   * list after a restart. Optional fields therefore use absent properties
   * (`model`/`provider`/`lastModel`/`contextWindow` are simply not set until
   * a value is known) instead of `undefined`-valued ones. Reads via
   * `state.model` are identical for both shapes (`undefined` on miss).
   */
  model?: string;
  provider?: string;
  lastModel?: string;
  contextWindow?: number;
  requests: RequestRecord[];
  /**
   * The number of turn runs in `requests` (a run = consecutive records
   * sharing one `turn`). Maintained incrementally at the single append site
   * and recomputed when a trim replaces the array, so the retention trim's
   * cap check stays O(1) per event instead of walking every retained
   * request. Absent on rows folded before the field existed — the first
   * post-restore event recomputes it once (the same additive-optional shape
   * as `detailRev`).
   */
  turnRuns?: number;
  events: ContextEventRecord[];
  /**
   * Recently removed surface nodes (stamped COPIES carrying `gone`), in
   * removal order. Feeds the Context browser's per-step reconstruction.
   * Bounded two ways in trimState: capped to `maxArchiveNodes`, and pruned
   * to removals after the oldest retained request (older removals can only
   * serve steps the requests trim already forgot).
   */
  archived: SurfaceNode[];
  /**
   * Session-cost raw material: cumulative billed-token totals per
   * (provider, model), split into pricing periods for DeepSeek (see
   * SessionCostUsage / CostModelUsage). Running totals — never trimmed, so
   * the estimate always covers the COMPLETE session log even after the
   * request/event retention bounds cut in. Absent until a usage-reporting
   * request with a known model folds.
   */
  cost?: SessionCostUsage;
  /**
   * Whole-session human-input tally (see Snapshot.humanInputs): every
   * non-injection `user/message` plus every answered `ask_user_question`
   * result. Running total — never trimmed, like `cost`/`timing`. Absent until
   * the first human input folds.
   */
  humanInputs?: number;
  /**
   * The user's newest own message as a bounded one-line preview (the surface
   * node's first-text line). Last-wins — a newer human input replaces it, a
   * text-less one (images only) keeps the previous line. Additive-optional
   * like the 0.47 fields: cached rows folded before the field existed read
   * without it and the card just hides its preview line.
   */
  lastUser?: string;
  archiveFloor?: number;
  /**
   * The detail collections' revision marker (see ContextTimelineDetail):
   * bumped by every fold that mutates the request records, context events,
   * live surface, or the removed-node archive — the slim wire head carries
   * it so an open tab knows its fetched detail went stale. Absent until the
   * first detail fold (undefined reads as 0; never materialize an
   * `undefined`-valued property — the plain-JSON precondition above).
   */
  detailRev?: number;
  /**
   * Whole-session timing totals (see TimingTotals) — running sums over the
   * COMPLETE session log, like `cost`. Absent until the first step or tool
   * lifecycle folds in; created once and cloned-on-touch afterwards (the
   * object is shared with the persisted previous state — see `ensure`).
   */
  timing?: TimingTotals;
  /**
   * The open step's start instant, armed by `step/start` and consumed by the
   * `assistant/message` (TTFT/generation split) and `step/end` (wall time)
   * that follow it; the message's embedded stream stamps `firstToken` —
   * absent when the stream carried none (an aborted step), which leaves that
   * call's model time unattributed. One slot, not a map: steps are sequential
   * in the log, so the newest `step/start` is the one those events close — a
   * hostile interleaved log degrades to skipped durations, never to
   * unbounded state. Same arm/remove lifecycle as `pendingShadowedSeqs`.
   */
  stepStart?: {
    time: number;
    firstToken?: number;
  };
  /**
   * The timing strip's painted spans (shared/types.ts TimingSpan): every
   * completed step's time slices in log order, stamped with their REAL
   * instants — the TTFT wait, the decode blocks in stream order, the tool-run
   * windows, and the in-step residue. The client packs them gapless, each
   * band's width its share of the cumulative active time (idle time BETWEEN
   * steps carries no span and takes no track). Bounded by TIMING_SPANS_MAX
   * (newest tail kept). Flushed per step at `step/end` from the `stepSpans`
   * accumulator.
   */
  spans: TimingSpan[];
  /**
   * The open step's accumulated painted spans: the assistant message pushes
   * the model slices (TTFT + the decode blocks), each paired tool result its
   * run window; `step/end` clamps them into the step window, de-overlaps
   * first-wins (parallel runs paint their union), fills the holes with the
   * residue kind, and flushes the tiling into `spans`. Absent until the first
   * in-step span; DELETED at the flush (the plain-JSON precondition). Same
   * arm/remove lifecycle as `stepStart` — never written in place, always
   * replaced, so no CloneKey covers it.
   */
  stepSpans?: TimingSpan[];
  /**
   * Tool callId → the call's name, start instant, and raw arguments, armed by
   * `tool/call` and DELETED when its `tool/result` folds in (one result per
   * call, in log order) — the map stays at pending-call size instead of
   * growing for the session's whole lifetime (it is persisted state,
   * shallow-copied by every fold step). The start instant prices the call's
   * duration into `timing.toolsMs` when the result arrives; the raw arguments
   * feed the file-op derivation (shared/fileOps.ts) at that same moment.
   */
  callNames: Record<string, {
    name: string;
    start: number;
    argsRaw?: string;
  }>;
  /**
   * Seq list of the surface nodes the next replacement will shadow, armed by
   * the metering event (`compaction/summary` | `compaction/prune`) and
   * consumed by the replacement that must follow it synchronously. The
   * producer's shadow price covers exactly these seqs — which can differ
   * from the replacement's declared range (pruned replacement nodes keep
   * their own seqs, beyond the range end) — so removal must follow the seqs.
   * Absent until armed, and REMOVED (not set to `undefined`) when consumed,
   * to keep the state plain JSON for the projection cache.
   */
  pendingShadowedSeqs?: number[];
  /**
   * The seq of the compaction/prune event that armed `pendingShadowedSeqs` —
   * the shadowed path rewrites that event's `tokens` from the gross shadow
   * price to the NET freed amount (removed nodes minus the synchronous
   * replacement), so the row matches the drop the trend chart shows. Same
   * arm/remove lifecycle as `pendingShadowedSeqs`.
   */
  pendingShadowEventSeq?: number;
  /**
   * The fold-derived file-operation log (the File Activity card's raw
   * material, shared/fileOps.ts): one record per executed file op, appended
   * in log order — at `tool/result` (the armed call's arguments + the
   * result's meta) and at a run_code result's flush of its nested
   * dispatches. Bounded by `maxFileOps`; the trim stamps `fileOpsFloor`.
   */
  fileOps: FileOpRecord[];
  /** The newest dropped op's seq (the card's coverage floor for the served op log). */
  fileOpsFloor?: number;
  /**
   * Nested Code-Mode ops buffered by their top run_code call id until the
   * parent's result folds (the dispatch events land BEFORE it, and the ops'
   * locate target is that result's seq). Flushed (and the key deleted) when
   * the result with that callId folds; absent until the first dispatch books
   * an op. Bounded by PENDING_CODE_OPS_MAX — a hostile log that never
   * settles a run_code cannot grow it.
   */
  pendingCodeOps?: Record<string, FileOpRecord[]>;
}
//#endregion
//#region src/shared/types.d.ts
declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionMap {
    /**
     * The plugin's context timeline: current composition, counters, and the
     * headline anchor. Since the split generation the wire value is the SLIM
     * head (every delivery channel — session.list rows, control baselines,
     * push frames — carries it whole); the per-request history, context
     * events, and the surface/archive collections ride the on-demand detail
     * channel ({@link ContextTimelineDetail}, host/detail.ts). Channel-less
     * hosts keep the inline generation (the collections stay in the value).
     * Key absence = the plugin's host half is not composed.
     */
    contextTimeline: ContextTimeline;
    /**
     * The request-header CONTENT epochs (full system prompt + tool schemas)
     * behind the timeline's envelope figures. A separate unit so the hot
     * `contextTimeline` value stays lean: headers change rarely, so this
     * value (and its pushes) change only when a `request/header` lands.
     * The Context browser card reads it to show the actual prompt/schema
     * content of a picked step (key absence = older host: tokens only).
     */
    contextHeaders: ContextHeaders;
    /**
     * The per-day activity ledger (billed tokens + completed requests keyed
     * by local day) behind the Context Dashboard's heatmap — the timeline's
     * "current snapshot" cannot draw a per-day chart, so the overview reads
     * this off every session-list row's projection column. Tiny (one small
     * record per day, retention-capped), so riding every list row costs
     * nothing next to the timeline head. Key absence = older host: the
     * heatmap degrades to its empty note.
     */
    contextActivity: ContextActivity;
  }
  interface SessionProjectionStateMap {
    contextTimeline: TimelineState;
    contextHeaders: HeadersState;
    contextActivity: ActivityState;
  }
}
/**
 * The priced surface buckets. `skill` carries every skill-machinery content
 * the harness injects (issue #66): the `<available_skills>` catalog digest,
 * a user-explicit `/name` invocation's instructions message, and the content
 * a `skill`-tool load returns (modeled as a tool result by the harness).
 */
type Category = 'user' | 'inject' | 'skill' | 'assistant' | 'tool';
/**
 * One live system-prompt node (Snapshot.systems) — the harness models the
 * system prompt as a surface node, so its TEXT is fetched on demand from the
 * `system/message` event at `seq`. `tokens` is the node's heuristic
 * price (0 for a dormant empty node, which the harness reads as "no system
 * prompt"); the effective figure is the LAST node with `tokens > 0`.
 */
interface SystemPromptNode {
  seq: number;
  time: number;
  tokens: number;
}
/**
 * The stats board's count figures, precomputed host-side over the RETAINED
 * request/event records (the same set the detail payload serves). Carried by
 * the split-generation wire head so the board — and the Agent card's
 * per-session request tally — never need the collections themselves.
 * `steps` doubles as the retained request-record count.
 */
interface TimelineCounts {
  turns: number;
  steps: number;
  injects: number;
  compactions: number;
  prunes: number;
}
/**
 * The newest retained request record's billing summary — the headline's
 * derived-occupancy anchor (`prompt + surface movement since`), carried by
 * the split-generation wire head so the headline never needs the request
 * records themselves.
 */
interface TimelineLast {
  seq: number;
  total: number;
  prompt?: number;
}
/** One day's ledger entry in the `contextActivity` projection. */
interface ActivityDay {
  /**
   * Billed tokens folded from provider-reported usage that day (prompt-side
   * input + cache read/write + output). Requests without a usage settlement
   * count only toward `requests` — a fabricated 0 never understates the day.
   */
  tokens: number;
  /** Completed model calls (assistant settlements) that day. */
  requests: number;
  /**
   * The day's billed buckets keyed provider → model → pricing period — the
   * same SessionCostUsage raw material the timeline's session-cost totals
   * carry, scoped to the day the requests INITIATED in, so the client prices
   * each day off the same model-price book as the KPI band. ADDITIVE-OPTIONAL:
   * absent on rows folded before the field existed (older plugin builds), on
   * days whose settlements predate any model header, and on settlements the
   * provider left unmetered — the usage chart degrades to tokens-only bars.
   */
  cost?: SessionCostUsage;
}
/**
 * The per-session daily activity ledger (`contextActivity` wire value):
 * day key (`YYYY-MM-DD`, host-local — see shared/days.ts) → that day's
 * billed volume, retention-capped by the fold. The Context Dashboard merges
 * every listed session's ledger into its activity heatmap.
 */
interface ContextActivity {
  days: Record<string, ActivityDay>;
}
/**
 * The per-user display-preference vocabulary of the `dsh-context` settings
 * namespace — the ONE declaration both halves share: the Host registers the
 * namespace schema against it (host/settings.ts), the Client binds the scope
 * and edits fields by name (client/settings.ts). Type-only, so both bundles
 * erase it.
 */
type DefaultGranularity = 'step' | 'turn';
type DefaultTrendMode = 'total' | 'delta';
/** File Activity row order: most operations first, most-recently-touched first, or path ascending. */
type DefaultFileSort = 'count' | 'latest' | 'path';
/** Tool-definition row order: largest schema first, most call hits first, or name ascending. */
type DefaultToolSort = 'size' | 'count' | 'name';
/** Where the Context view is offered: the conversation tab, the right Sidebar, or both. */
type DefaultPlacement = 'all' | 'tab' | 'sidebar';
/** Whether the Context Insights panel's sidebar entry is offered at all. */
type InsightsEntry = 'show' | 'hide';
interface Snapshot {
  ok: boolean;
  /**
   * The host's baseline-gate record, present ONLY when the running harness
   * is below the plugin's supported baseline: the host then folds nothing
   * and every figure in this snapshot is zero/empty. The client keeps
   * rendering the (blank) cards and pops the upgrade gate modal naming
   * `current` (the detected harness version) and `minimum` (the baseline).
   */
  unsupported?: {
    current: string;
    minimum: string;
  };
  model?: string;
  provider?: string;
  contextWindow?: number;
  current: {
    system: number;
    tools: number;
    user: number;
    inject: number;
    skill: number;
    assistant: number;
    tool: number;
    total: number;
  };
  /**
   * Image blocks live in the CURRENT context (user uploads plus tool-result
   * images, nested blocks included) — the sum over the live surface nodes'
   * `imgs`, so compaction/prune shrink it. Absent from older hosts; clients
   * treat absence as zero.
   */
  images?: number;
  /**
   * Tool calls whose result is live in the CURRENT context (one `tool/result`
   * folds to one `tool` surface node). Calls still in flight and results
   * compacted/pruned out of the surface are not counted. Absent from older
   * hosts; clients treat absence as zero.
   */
  toolCalls?: number;
  /**
   * Whole-session human-input tally: every non-injection `user/message`
   * (the user's own messages) plus every answered `ask_user_question`
   * result (one per answer submission). A running total over the COMPLETE
   * log — turns the retained window no longer holds still count. Absent
   * from older hosts; clients treat absence as zero.
   */
  humanInputs?: number;
  /**
   * The user's newest own message as a one-line bounded preview (first text
   * block, whitespace collapsed, ~80 chars): the session cards' footer line.
   * Additive-optional — absent from rows folded before the field existed
   * (older hosts, idle sessions' cached rows); clients hide the line then.
   */
  lastUser?: string;
  /**
   * Split-generation head fields — present exactly when the host serves the
   * SLIM head (the heavy collections moved to the on-demand detail channel,
   * host/detail.ts) and absent on the inline generation (older or
   * channel-less hosts serve the collections in place). `detailRev` is the
   * detail's revision marker: it bumps whenever the detail collections
   * change, so an open tab refetches on the push alone.
   */
  counts?: TimelineCounts;
  last?: TimelineLast;
  detailRev?: number;
  /**
   * The per-request history / context-event collections. On the split
   * generation these stay ABSENT from the wire value (every session.list row,
   * control baseline, and push frame would carry them whole otherwise); the
   * client fills them from the detail channel ({@link ContextTimelineDetail}).
   */
  requests: RequestRecord[];
  events: ContextEventRecord[];
  /**
   * Cumulative session-cost raw material (per-provider, per-model billed
   * token totals — see SessionCostUsage). Absent until a request with a
   * known model reports usage.
   */
  cost?: SessionCostUsage;
  /**
   * Whole-session timing totals (see TimingTotals). Absent until the first
   * step lifecycle completes in the log (older plugin builds never folded
   * one — clients treat absence as an empty timing card).
   */
  timing?: TimingTotals;
  /**
   * The live system-prompt nodes, oldest first — the browser's per-step source
   * for the System section. Absent on rows folded before this field existed
   * (older plugin builds; the client then falls back to the header epoch's
   * own `systemTokens`, the legacy wire shape those builds served).
   */
  systems?: SystemPromptNode[];
  /**
   * The served live surface: the newest `maxNodes` tail PLUS every live inject node older than the tail (injections land first and are
   * few,
   * so they are pinned). Seq-ordered, oldest first.
   */
  nodes: SurfaceNode[];
  /** Live nodes not served (the overflow beyond `maxNodes`, minus pinned injects — see `nodes`). */
  droppedNodes: number;
  /**
   * Recently REMOVED surface nodes (compaction/prune shadows), each stamped
   * with `gone` (the replacing event's seq). Together with `nodes` this lets
   * the Context browser reconstruct the assembled surface of any retained
   * step: alive at request R = seq < R.seq && (gone undefined || gone > R.seq).
   */
  archive: SurfaceNode[];
  /**
   * Coverage floor of the served live `nodes`: the newest seq among the
   * `droppedNodes` live nodes not served. Present only when droppedNodes > 0.
   */
  surfaceFloor?: number;
  /**
   * Coverage floor of `archive`: the newest `gone` among archive entries the
   * retention bounds dropped. Steps with seq < archiveFloor may miss removed
   * nodes (the browser shows the reconstruction as approximate).
   */
  archiveFloor?: number;
  /**
   * The fold-derived file-operation log and its trim floor — present on the
   * INLINE wire value (channel-less hosts) and on the detail payload
   * (ContextTimelineDetail), absent from the slim head (they ride the detail
   * channel there).
   */
  fileOps?: FileOpRecord[];
  fileOpsFloor?: number;
  /**
   * The timing strip's painted spans (see TimingSpan) — present on the INLINE
   * wire value and on the detail payload, absent from the slim head (they ride
   * the detail channel there) and from rows folded before the collection
   * existed (older hosts; the client then shows no strip).
   */
  spans?: TimingSpan[];
}
/**
 * The on-demand DETAIL payload of the split `contextTimeline` generation —
 * the heavy collections (per-request records, context events, the served
 * surface window, and the removed-node archive) that the slim wire head no
 * longer carries through every delivery channel. The host serves it off the
 * live fold state at the `/dsh-context` `detail` endpoint (host/detail.ts);
 * `rev` mirrors the head's `detailRev` at build time and acts as the
 * client's latest-wins cursor.
 */
interface ContextTimelineDetail {
  rev: number;
  /**
   * The slim wire head at the SAME fold cut as the collections: the
   * composition scalars (`current`), the window/model envelope, and the
   * precomputed counts. Sessions listed cold (never attached since the
   * requesting unit last changed) carry no `contextTimeline` projection row
   * for the browser's list reads, so the Agent network card fetches this
   * head per node to render their composition rings. The host always serves
   * it; optional so a payload missing it still serves the collections (the
   * detail cards) and only the ring composition degrades.
   */
  head?: ContextTimeline;
  requests: RequestRecord[];
  events: ContextEventRecord[];
  nodes: SurfaceNode[];
  droppedNodes: number;
  archive: SurfaceNode[];
  surfaceFloor?: number;
  archiveFloor?: number;
  /**
   * The fold-derived file-operation log (shared/fileOps.ts): one record per
   * executed file op, newest-retained, covering the full log (never
   * window-bound like the client-side join derivation it replaces on this
   * generation). Code-Mode nested dispatches book ops located on their
   * parent run_code result (`parent`).
   */
  fileOps?: FileOpRecord[];
  /** The newest dropped op's seq when the op log trimmed (coverage honesty, same family as archiveFloor). */
  fileOpsFloor?: number;
  /**
   * The timing strip's painted spans (see TimingSpan): the completed steps'
   * time slices in log order, positioned by their real instants. Additive-
   * optional: a payload folded before the collection existed (older hosts)
   * serves without it, and the timing card shows no strip then.
   */
  spans?: TimingSpan[];
}
/**
 * One executed file operation (a settled file-tool call with a resolved
 * target), folded host-side from the durable tool lifecycle: the call's
 * name+arguments (`tool/call`), the result's presentation meta and error
 * (`tool/result`), or a nested Code-Mode settle (`tool/ptc-dispatch`,
 * located on its parent run_code result via `parent` + `program`).
 *
 * `gone` is NOT host-stamped: the client joins it from the detail's archive
 * at render time (the op's result node leaving the live surface marks where
 * its content is still viewable). Line deltas are estimates read off the
 * call ARGUMENTS (an edit's old/new strings, a write's content), never off
 * result payloads.
 */
interface FileOpRecord {
  seq: number;
  /** The op's file; for a pathless search the searched PATTERN (`pattern: true`). */
  path: string;
  kind: 'read' | 'write' | 'search';
  tool: string;
  time?: number;
  err: boolean;
  added: number;
  removed: number;
  /** What was searched for, when a search named both a path and a pattern. */
  detail?: string;
  /** Meta-attributed search op only: matched lines the result reported for this file. */
  hits?: number;
  /** Read ops only: the exact 1-based window the result meta reported, else the `limit`-argument estimate (`est: true`). */
  read?: {
    start: number;
    count: number;
  } | {
    count: number;
    est: true;
  };
  /** Nested Code-Mode op only: the run_code result node the op ran under (the locate target). */
  parent?: number;
  /** Nested Code-Mode op only: the run_code program's model-authored description. */
  program?: string;
  /** The searched-pattern marker: `path` is a pattern, not a file — display must not relativize it. */
  pattern?: true;
  /** Client-joined archive stamp (see the type note); absent on the wire. */
  gone?: number;
}
/**
 * The `contextTimeline` projection's whole value — the same snapshot the Client has always rendered. `ok` is always `true` here (a
 * delivered projection is by definition available); kept for wire compatibility with the snapshot shape.
 */
type ContextTimeline = Snapshot;
/**
 * One painted span of the timing card's session-time strip (the card's bottom
 * band): a completed step's time slice — the TTFT wait, one decode block (in
 * stream order), one tool-run window, or an in-step residue gap — folded
 * host-side at `step/end`. The instants are the slice's REAL occurrence times
 * (the hover tip reads them); the strip packs the spans gapless in log order,
 * each band's width its share of the session's cumulative active time (idle
 * time BETWEEN steps carries no span and takes no track). `end` > `start`
 * always (the fold drops zero/negative slices).
 */
interface TimingSpan {
  /** The slice kind — the timing card's own slice vocabulary (same keys, same colors). */
  kind: 'ttft' | 'reasoning' | 'text' | 'toolarg' | 'tools' | 'other';
  start: number;
  end: number;
}
/**
 * Cumulative billed-token totals for one pricing bucket of the session-cost
 * estimate (host-folded, never trimmed — running totals over the COMPLETE
 * session log, immune to the request/event retention bounds).
 */
interface CostBucketTotals {
  uncached: number;
  cacheRead: number;
  cacheWrite: number;
  output: number;
}
/**
 * One completed tool name's whole-session call tally behind the timing
 * card's top-tools ranking (running totals, never trimmed).
 */
interface ToolTimingTotals {
  calls: number;
  ms: number;
}
/**
 * Whole-session timing totals, host-folded from the durable `step/start` /
 * `step/end` / `tool/call` / `tool/result` lifecycle plus the model call's
 * first token (running totals over the COMPLETE session log — the same
 * never-trimmed framing as `cost`). The first token comes from the call's
 * own embedded stream (`assistant/message.data.stream` /
 * `assistant/attempt.data.stream`), matching the harness's own
 * session-stats fold. Durations are wall-clock milliseconds: `wallMs` sums
 * whole steps, `ttftMs` the step-start → decode-start slice (the model wait)
 * and `genMs` the decode-start → assistant-message slice (the generation) —
 * both only over calls whose stream carried a token delta, `toolsMs` the sum
 * of per-call tool durations (parallel calls each count, so it can overlap).
 * The decode window opens at the first OBSERVABLE instant — the first token,
 * or an earlier `block-start` marker the token packing could not stamp (a
 * redacted reasoning block leaves no chunk behind): anchoring at the token
 * would charge the marker-tiled window to the wait as well, double-counting
 * it past 100% in the legend. Absent until the first step lifecycle
 * completes in the log.
 *
 * The generation window itself splits by WHAT was being decoded, off the
 * stream's `block-start` framing (`blockType`): `reasoningMs` (the model's
 * thinking), `textMs` (the answer text), and `toolArgMs` (the tool-call
 * arguments). Each marker owns the interval up to the next one (the last one
 * up to the assistant message), so the three tile the marker span — exactly
 * `genMs` when the first marker leads the first token (the window opens
 * there); when the first marker sits marginally PAST the token the lead-in
 * gap stays inside `genMs` unattributed, so the buckets never exceed it.
 * They are ADDITIVE-OPTIONAL: cached projection rows written before
 * the split carry `genMs` without them, so the card falls back to the
 * un-split shape instead of the cache row being discarded (the
 * stateVersion-15 rationale in host/timeline.ts).
 */
interface TimingTotals {
  /** Summed wall time of completed steps (the session's active time). */
  wallMs: number;
  /** Summed step-start → decode-start time (the model wait, TTFT). */
  ttftMs: number;
  /** Summed decode-start → assistant-message time (the generation). */
  genMs: number;
  /** Reasoning-decode slice of `genMs` (the model's thinking). */
  reasoningMs?: number;
  /** Counted reasoning-decode blocks (the Thinking slice's tally). */
  reasoningBlocks?: number;
  /** Answer-text decode slice of `genMs`. */
  textMs?: number;
  /** Counted answer-text decode blocks (the Answer slice's tally). */
  textBlocks?: number;
  /** Tool-call-argument decode slice of `genMs`. */
  toolArgMs?: number;
  /**
   * Counted tool-call-argument decode blocks — one per tool call whose
   * arguments the stream decoded (the Tool args slice's tally). The counts are
   * ADDITIVE-OPTIONAL like their spans: a row cached before they existed (or a
   * call whose stream framed no blocks) carries none, and the card qualifies
   * only what was actually counted.
   */
  toolArgBlocks?: number;
  /**
   * The decode-throughput seat, paired exactly as the harness's own
   * session-stats fold pairs them: `speedTokens` sums provider-reported
   * output tokens and `speedMs` the first-token → assistant-message
   * windows, over the calls that carried BOTH a first-token stamp and a
   * usage report — a subset of `genMs`, which counts every token-stamped
   * call regardless of usage. `speedMs` KEEPS the first-token anchor (not
   * the marker-aware decode start): it is the harness-parity figure.
   * Additive-optional: cached rows written before
   * the seat existed lack them, and the card falls back to no chip.
   */
  speedTokens?: number;
  speedMs?: number;
  /** Completed model calls (assistant messages folded). */
  calls: number;
  /** Summed per-call durations of completed tool calls. */
  toolsMs: number;
  /** Completed tool calls (call/result pairs folded). */
  toolCalls: number;
  /** Per-tool-name tallies behind the timing card's ranking (bounded). */
  tools: Record<string, ToolTimingTotals>;
}
/**
 * One billed model's cumulative totals split by pricing period. Providers
 * without period-based pricing book everything under `peak` (the list-price
 * period); DeepSeek splits at fold time — peak windows bill at list price,
 * off-peak (all other hours) at half.
 */
interface CostModelUsage {
  peak?: CostBucketTotals;
  off?: CostBucketTotals;
}
/**
 * The session-cost estimate's raw material: cumulative provider-reported
 * billed-token totals, keyed by the request envelope's DSH provider id (''
 * when a log carries none) and then by its model id — the exact (provider,
 * model) faces the Client's model-price book resolves (the models.dev
 * registry, client/modelPrices.ts). Running totals per key; absent until a
 * request with a known model reports usage.
 */
interface SessionCostUsage {
  [provider: string]: {
    [model: string]: CostModelUsage;
  };
}
/** One model-visible message on the surface, with its heuristic token price. */
interface SurfaceNode {
  seq: number;
  time?: number;
  cat: Category;
  tokens: number;
  /** Image blocks inside this node's message (absent when zero). */
  imgs?: number;
  /**
   * Removal marker, present only on `archive` entries: the seq of the
   * replacement surface event that shadowed this node (compaction/prune).
   * The node is part of the assembled context of every request with
   * seq > this node.seq and seq < gone.
   */
  gone?: number;
  form?: string;
  /**
   * The producer identity the matching inject event names (host pricing.ts
   * `injectionSourceName`: the plugin id, the reconciled instruction files,
   * or the durable kind). Stamped on injection nodes alongside the event, so
   * the browser rows label them the way the events card does; absent when the
   * source carries no readable identity or the node predates the stamp.
   */
  name?: string;
  text?: string;
  tool?: string;
  err?: boolean;
  skill?: string;
  calls?: string[];
}
/** One answered model call (a step); consecutive records of one turn form it. */
interface RequestRecord {
  turn?: number;
  step?: number;
  time: number;
  seq: number;
  system: number;
  tools: number;
  user: number;
  inject: number;
  assistant: number;
  tool: number;
  total: number;
  prompt?: number;
  /**
   * Skill-machinery tokens of this request (the `skill` composition
   * category — catalog digests, invocation instructions, `skill`-tool
   * loads). Always written by the current fold; absent on rows folded
   * before the category existed (read as 0).
   */
  skill?: number;
  /**
   * Billed cache-read (served) prompt tokens of this request — the
   * hit-rate numerator against `prompt` (input + cacheRead + cacheWrite).
   * Absent on older hosts / usage-less requests; zero is a real value.
   */
  cacheRead?: number;
  output?: number;
  /**
   * Turn-mode aggregate marker, set by the Client's aggregateByTurn (one bar
   * per turn shows its LAST step's record). The Host never sets it.
   */
  stepCount?: number;
  /**
   * Delta-mode signed net change, set by the Client's deltaOf (only present
   * on the delta-transformed records the TrendChart plots). The Host never
   * sets it.
   */
  net?: number;
}
/** A notable context event (compaction, prune, injection, model switch). */
interface ContextEventRecord {
  seq: number;
  time: number;
  kind: 'compaction' | 'prune' | 'inject' | 'model' | 'mode';
  form?: string;
  tokens?: number;
  count?: number;
  sub?: string;
  name?: string;
  /** One-line producer account (notice-form summary), shown after the name. */
  detail?: string;
  from?: string;
  to?: string;
  /** Turn/step of the request logged right BEFORE the event (host-stamped). */
  fromTurn?: number;
  fromStep?: number;
  /** Turn/step of the request this event contributed to (host-stamped). */
  turn?: number;
  step?: number;
}
/** One tool of a request-header epoch, with its display price. */
interface HeaderTool {
  name: string;
  tokens: number;
  /**
   * The registering plugin's label, when attribution is known: the host's
   * best-effort attribution (`mcp:<server>` for MCP tools, or the pinned
   * first-party package map), or a `plugin` field carried by the raw header
   * entry — no supported-baseline harness path writes one, but the read
   * stays defensive for foreign/newer producers. `UNKNOWN_TOOL_SOURCE` marks
   * a tool whose provider predates the attribution hook; absent means
   * nothing is known and the browser shows no tag.
   */
  plugin?: string;
}
/**
 * One request-header epoch's METADATA: the epoch boundaries and token prices
 * in force from this event's seq until the next epoch. The epoch CONTENT
 * (full system prompt text, tool descriptions/schemas) is not projected —
 * every session.list row, control baseline, push frame, and projection-cache
 * checkpoint would otherwise carry it per session × epoch. The client
 * fetches one epoch's content on demand (a seq-anchored history read off
 * `seq`) as a {@link HeaderEpochContent}.
 */
interface HeaderRecord {
  seq: number;
  time: number;
  /** The epoch's estimated system-prompt tokens; absent when it logged no system prompt. */
  systemTokens?: number;
  tools: HeaderTool[];
}
/** The `contextHeaders` projection value: the bounded epoch list (newest last). */
interface ContextHeaders {
  headers: HeaderRecord[];
}
/** One currency's DeepSeek open-platform balance figures. */
interface PlatformBalanceEntry {
  /** The ISO code the platform reported (`CNY` / `USD`). */
  currency: string;
  /** Total available funds: `granted` + `toppedUp`. Derived here rather than read
   * from the platform's own `total_balance`, which rounds independently of its
   * parts and can land a cent away from what the breakdown beside it shows. */
  total: number;
  /** The not-expired granted (gift) balance. */
  granted: number;
  /** The topped-up balance. */
  toppedUp: number;
}
/**
 * The DeepSeek open-platform balance, served by the plugin's
 * `/api/dsh-context/balance` fetch route (host/balance.ts). `null` on the
 * wire — and nothing rendered client-side — whenever the platform is not
 * configured or the read fails: the capsule only ever shows a live figure.
 */
interface PlatformBalance {
  /** Whether the platform reports the balance sufficient for API calls. */
  isAvailable: boolean;
  /** One entry per currency the account holds; at least one. */
  balances: PlatformBalanceEntry[];
}
//#endregion
//#region src/host/config.d.ts
export interface Config {
  /** Cap on kept per-step request records (the hard step backstop). */
  maxRequestSteps?: number;
  /** Newest whole-turn window kept; trimming crosses whole turns, never mid-turn. */
  maxKeptTurns?: number;
  maxEvents?: number;
  /**
   * Served surface nodes (newest carry the signal; live inject nodes are pinned — they land first and are few). Deliberately generous:
   * auto-compaction keeps healthy surfaces far below it, so the browser effectively lists every live node; the bound is a
   * pathological-session backstop (each push ships the whole value, ~150B/node).
   */
  maxNodes?: number;
  /** Removed (shadowed) surface nodes kept for per-step reconstruction. */
  maxArchiveNodes?: number;
  /** Fold-derived file-operation records kept (the File Activity card's raw material). */
  maxFileOps?: number;
  /** Where the Context view is offered (the conversation tab, the right Sidebar, or both). */
  defaultPlacement?: DefaultPlacement;
  /** Timeline default granularity (per step or per turn). */
  defaultGranularity?: DefaultGranularity;
  /** Timeline default trend mode (total or delta). */
  defaultTrendMode?: DefaultTrendMode;
  /** Tool-definition row default order. */
  defaultToolSort?: DefaultToolSort;
  /** File Activity row default order. */
  defaultFileSort?: DefaultFileSort;
  /** Whether the Context Insights panel's sidebar entry is offered. */
  insightsEntry?: InsightsEntry;
}
/** The cordis `Config` validator and the Config-form generation's served schema. */
export declare const Config: z$1<Schemastery.ObjectS<NoInfer<{
  maxRequestSteps: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxKeptTurns: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxEvents: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxNodes: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxArchiveNodes: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxFileOps: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  defaultPlacement: z$1<"all" | "sidebar" | "tab", "all" | "sidebar" | "tab", Mode>;
  defaultGranularity: z$1<"step" | "turn", "step" | "turn", Mode>;
  defaultTrendMode: z$1<"delta" | "total", "delta" | "total", Mode>;
  defaultDeltaBase: z$1<"step" | "turn", "step" | "turn", Mode>;
  defaultToolSort: z$1<"count" | "name" | "size", "count" | "name" | "size", Mode>;
  defaultFileSort: z$1<"count" | "latest" | "path", "count" | "latest" | "path", Mode>;
  insightsEntry: z$1<"hide" | "show", "hide" | "show", Mode>;
}>>, Schemastery.ObjectT<NoInfer<{
  maxRequestSteps: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxKeptTurns: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxEvents: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxNodes: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxArchiveNodes: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  maxFileOps: z$1<number, number, Mode extends "volatile" | "volatile-defined" ? "volatile-defined" : "defined">;
  defaultPlacement: z$1<"all" | "sidebar" | "tab", "all" | "sidebar" | "tab", Mode>;
  defaultGranularity: z$1<"step" | "turn", "step" | "turn", Mode>;
  defaultTrendMode: z$1<"delta" | "total", "delta" | "total", Mode>;
  defaultDeltaBase: z$1<"step" | "turn", "step" | "turn", Mode>;
  defaultToolSort: z$1<"count" | "name" | "size", "count" | "name" | "size", Mode>;
  defaultFileSort: z$1<"count" | "latest" | "path", "count" | "latest" | "path", Mode>;
  insightsEntry: z$1<"hide" | "show", "hide" | "show", Mode>;
}>>, "plain">;
//#endregion
//#region src/host/index.d.ts
export declare const name = "dsh-context";
export declare const inject: string[];
export declare function apply(ctx: Context, config: Config): void;
//#endregion
export type { ActivityDay, ActivityState, Category, ContextActivity, ContextEventRecord, ContextHeaders, ContextTimeline, ContextTimelineDetail, HeaderRecord, HeaderTool, HeadersState, PlatformBalance, PlatformBalanceEntry, RequestRecord, Snapshot, SurfaceNode, TimelineCounts, TimelineLast, TimelineState };