// TaskBridge 运行时：监听会话事件，把宿主 todo/工具调用同步进任务实体。
// 事实依据：dsh session/event 签名 (session, event)；todo/write data.todos；
// tool/call data.arguments 为 JSON 字符串；fs 工具名 read/write/edit/read_image，参数 file_path。
import path from 'node:path'
import { createHash, randomUUID } from 'node:crypto'
import { memoryRootFor, resolveProjectMemoryRoot } from '../util/fs.js'
import { ProjectMemoryStore } from '../store.js'
import { stepContent, stepStatus } from '../util/task-view.js'

const FS_FILE_TOOLS = new Set(['read', 'write', 'edit', 'read_image'])
const WRITE_TOOLS = new Set(['write', 'edit']) // 编辑/写入 = 高热点
const READ_TOOLS = new Set(['read', 'read_image'])
const MAX_FILES_PER_TASK = 100
const TITLE_MAX = 24

export function hash8(text) {
  return createHash('sha256').update(String(text)).digest('hex').slice(0, 8)
}

export function slugifyTitle(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[^\w\u4e00-\u9fff]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, TITLE_MAX)
}

export function genTaskId(projectRoot, title) {
  const slug = slugifyTitle(title) || 'task'
  // 毫秒不是唯一性保证：两个会话在同一毫秒建同名任务会拿到同一个 id，
  // addTask 变成"同一 id 两次"，两个会话的绑定互相串台。补 6 位随机后缀。
  return `tsk_${hash8(projectRoot)}_${slug}_${Date.now().toString(36)}_${randomUUID().slice(0, 6)}`
}

/** 会话根不可用时统一的用户提示（/tasks、/task、/insight 共用）。 */
export const NO_PROJECT_ROOT_NOTE =
  '当前工作目录不是项目根（是家目录/系统目录且没有项目标记），项目记忆与任务清单已停用；请在项目目录内启动 dsh。'

/**
 * 项目根推导：与全插件同一套策略（util/fs.js 的 `resolveProjectMemoryRoot`）——
 * 最近的 VCS/清单标记优先；标记缺失但 cwd 本身是安全目录时退回 cwd（任务清单按
 * "会话工作目录"归属，没有标记的普通目录也要能用）；cwd 是家目录/系统/包管理器前缀
 * 且上方没有标记时返回 null。
 */
export function projectRootFor(cwd) {
  return resolveProjectMemoryRoot(cwd || process.cwd())
}

/** 没有可用项目根时返回 `{ root: null, store: null }`，调用方据此整段跳过。 */
export function taskStoreFor(cwd, config) {
  const root = projectRootFor(cwd)
  if (!root) return { root: null, store: null }
  return { root, store: new ProjectMemoryStore(memoryRootFor(root, config.memoryDir)).load() }
}

/** 把工具参数里的文件路径归一化为项目相对路径；项目外返回 null。 */
export function normalizeRelFile(root, file) {
  if (typeof file !== 'string' || !file) return null
  const abs = path.isAbsolute(file) ? file : path.resolve(root, file)
  const rel = path.relative(root, abs)
  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) return null
  return rel.split(path.sep).join('/')
}

/** content 可能是字符串或 ContentBlock[]，统一取首段文本。 */
export function firstTextOf(content) {
  if (typeof content === 'string') return content
  if (Array.isArray(content)) {
    for (const b of content) {
      if (b && typeof b.text === 'string' && b.text.trim()) return b.text
    }
  }
  return ''
}

/**
 * 反向接管：任务成为某会话绑定后，把任务步骤推成宿主 todo/write 快照，
 * 让 dsh 渲染的任务清单（UI/投影）变成我们这套任务的步骤。
 * 规则：任务没有步骤时不推（避免误清模型手头正在用的宿主清单）。
 * @returns {boolean} 是否实际推送
 */
export function adoptStepsToSession(session, task) {
  if (!session || typeof session.append !== 'function') return false
  const steps = Array.isArray(task?.steps) ? task.steps : null
  if (!steps || steps.length === 0) return false
  const todos = steps.map((s) => ({ content: String(stepContent(s)), status: stepStatus(s) }))
  session.append('todo/write', { todos })
  return true
}

/** 是否开启“任务接管时同步宿主清单”（config.tasklist.syncHostOnAdopt 默认 true）。 */
export function shouldAdoptToHost(config) {
  return config?.tasklist?.syncHostOnAdopt !== false
}

/**
 * 子代理会话判定：宿主 SessionHeader 对 in-process 子代理恒定写入
 * `origin: 'subagent'` 与 `delegationDepth`（parent depth + 1）。
 * 刻意不看 parentSession —— 那是 fork/seed 血缘，用户 fork 出来的顶层会话同样带它。
 */
export function isSubagentSession(session) {
  const header = session?.header
  if (!header) return false
  if (header.origin === 'subagent') return true
  return typeof header.delegationDepth === 'number' && header.delegationDepth > 0
}

/**
 * 标题优先级：清单首条 > 首条真人消息 > 'Untitled Task'（0.5.3 反转前两者）。
 * 真人消息只在清单没有可用文本时兜底：重启后 meta.firstHuman 是重启后的第一条消息
 * （常常只是半途闲聊，如"刚刚你卡死了，注意点"），拿它命名会把任务带偏。
 */
function pickTitle(meta, todos) {
  const firstTodo = todos?.[0]?.content
  if (typeof firstTodo === 'string' && firstTodo.trim()) return firstTodo.trim().slice(0, 48)
  const firstHuman = meta?.firstHuman?.trim()
  if (firstHuman) {
    // 用户消息常带指令前缀（"用 todo_write 规划：…"），优先取最后一个"："后的任务段
    const idx = Math.max(firstHuman.lastIndexOf('：'), firstHuman.lastIndexOf(':'))
    const seg = idx >= 0 ? firstHuman.slice(idx + 1).trim() : ''
    if (seg.length >= 2 && seg.length <= 48) return seg
    return firstHuman.slice(0, 48)
  }
  return 'Untitled Task'
}

/**
 * 热点排序：写过(编辑)的文件永远排前；同是写过按 lastWriteAt 倒序；
 * 纯读文件按 lastReadAt 倒序排在写区之后（任何读取都不会越过写过文件）。
 */
export function hotSortFiles(files, meta) {
  const m = meta || {}
  return (files || []).slice().sort((a, b) => {
    const A = m[a]
    const B = m[b]
    const aw = A && A.lastWriteAt ? 1 : 0
    const bw = B && B.lastWriteAt ? 1 : 0
    if (aw !== bw) return bw - aw
    if (aw) return String(B.lastWriteAt).localeCompare(String(A.lastWriteAt))
    return String(B.lastReadAt || '').localeCompare(String(A.lastReadAt || ''))
  })
}

/** 触碰文件后更新元数据并重排 task.files（写 vs 读分别记时间/次数）。 */
export function touchTaskFile(task, rel, kind, now) {
  task.fileMeta = task.fileMeta || {}
  if (!task.files.includes(rel)) task.files.push(rel)
  const m = task.fileMeta[rel] || {}
  m.n = (m.n || 0) + 1 // 兼容旧字段：读+写总数（保留，避免老任务语义漂移）
  // 读/写分计数（先只采集，不消费 —— 排序与注入仍只用 lastWriteAt/lastReadAt）
  if (kind === 'write') {
    m.writes = (m.writes || 0) + 1
    m.lastWriteAt = now
  } else if (kind === 'read') {
    m.reads = (m.reads || 0) + 1
  }
  m.lastReadAt = now
  task.fileMeta[rel] = m
  task.files = hotSortFiles(task.files, task.fileMeta)
  // 超限丢最冷的：列表已按热度降序，末尾即最冷。旧代码在**重排前** shift()，
  // 而那时 files 本身就是热序，shift 恰好把最热的那个文件（刚写的）丢掉、留下最冷的。
  while (task.files.length > MAX_FILES_PER_TASK) {
    const dropped = task.files.pop()
    delete task.fileMeta[dropped]
  }
}

/**
 * 单条会话事件处理（导出便于测试）：user/message 记首条真人文本并刷新 lastHumanAt；
 * todo/write → 已绑定则覆盖 steps，未绑定则自动新建任务并绑定（子代理会话除外，
 * 由 isSubagentSession 判定）；tool/call（fs 工具）→ 绑定任务 files 并集。
 */
export function onSessionEvent(config, session, event, meta) {
  const sessionId = session?.id
  const type = event?.type
  if (!sessionId || !type) return
  const now = new Date().toISOString()

  // 人类消息：记首条真人文本 + 若已绑定任务则刷新 lastHumanAt（供“模型自维护不回声任务卡”判断）
  if (type === 'user/message') {
    if (event.data?.source?.kind === 'user') {
      const text = firstTextOf(event.data?.content)
      const m = meta.get(sessionId) || {}
      if (!m.firstHuman && text) m.firstHuman = text
      m.lastHumanAt = now
      meta.set(sessionId, m)
      try {
        const { store } = taskStoreFor(session?.header?.cwd, config)
        if (!store) return
        store.commit((s) => {
          const tid = s.getBoundTaskId(sessionId)
          const task = tid ? s.getTask(tid) : null
          if (task && !task.archived) {
            task.lastHumanAt = now
            task.updatedAt = now
            s._dirtyTasks = true
          }
        })
      } catch {
        /* 人类消息戳记失败不影响主流程 */
      }
    }
    return
  }

  const { root, store } = taskStoreFor(session?.header?.cwd, config)
  // 没有项目根（家目录/系统目录会话）：不建档、不记文件、不落任何盘。
  if (!store) return

  if (type === 'todo/write') {
    const todos = event.data?.todos
    if (!Array.isArray(todos)) return
    store.commit((s) => {
      let task = s.getBoundTaskId(sessionId) ? s.getTask(s.getBoundTaskId(sessionId)) : null
      if (!task || task.archived) {
        // 空写 = 清空清单：不自动建档（避免"未绑定会话清空 todo"误建垃圾任务）
        if (todos.length === 0) return
        // 子代理会话不建档：否则每个子代理都铸一条项目任务（子代理任务融合另行设计）
        if (isSubagentSession(session)) return
        const title = pickTitle(meta.get(sessionId), todos)
        task = {
          id: genTaskId(root, title),
          projectHash: hash8(root),
          projectRoot: root,
          title,
          steps: null,
          files: [],
          fileMeta: {},
          archived: false,
          lastSessionId: sessionId,
          createdAt: now,
          updatedAt: now,
          lastActiveAt: now,
        }
        s.addTask(task)
        s.setBinding(sessionId, task.id)
      }
      task.steps = todos
      task.lastTodoAt = now // 模型/todo 最近一次自维护时刻
      task.updatedAt = now
      task.lastActiveAt = now
      task.lastSessionId = sessionId
      s._dirtyTasks = true
    })
    return
  }

  if (type === 'tool/call') {
    const taskId = store.getBoundTaskId(sessionId)
    if (!taskId) return
    const data = event.data
    if (!data?.name || !FS_FILE_TOOLS.has(data.name)) return
    let args
    try {
      args = typeof data.arguments === 'string' ? JSON.parse(data.arguments) : data.arguments
    } catch {
      return
    }
    const raw = typeof args?.file_path === 'string' ? args.file_path : null
    if (!raw) return
    const rel = normalizeRelFile(root, raw)
    if (!rel) return
    const kind = WRITE_TOOLS.has(data.name) ? 'write' : READ_TOOLS.has(data.name) ? 'read' : null
    if (!kind) return
    store.commit((s) => {
      const task = s.getTask(taskId)
      if (!task || task.archived) return
      touchTaskFile(task, rel, kind, now)
      task.lastActiveAt = now
      s._dirtyTasks = true
    })
  }
}

/** 插件接线：订阅 session/event；卸载时清会话元数据。 */
export function setupTaskbridge(ctx, config) {
  if (config.tasklist?.enabled === false) return
  const meta = new Map()
  ctx.on('session/event', (session, event) => {
    try {
      onSessionEvent(config, session, event, meta)
    } catch (err) {
      console.error('[dsh-project-memory] taskbridge:', err?.message)
    }
  })
  ctx.effect(() => () => meta.clear())
}
