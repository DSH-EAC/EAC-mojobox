// /tasks 用户命令：不经模型，直接展示本项目任务总览（非归档 + 归档计数 + 当前会话绑定）。
// 同时嵌入结构化 JSON 供 Client 端 Task Panel 解析渲染交互式面板。
// renderTaskSnapshot / buildTaskPayload 导出供 task-actions.js 复用（面板动作后返回同一快照）。
import { memoryRootFor } from '../util/fs.js'
import { ProjectMemoryStore } from '../store.js'
import { NO_PROJECT_ROOT_NOTE, projectRootFor } from '../setup/taskbridge.js'
import { fencedJson, invocationContext } from './invocation.js'
import { stepContent, stepProgress, stepStatus, timeAgo } from '../util/task-view.js'

export function buildTaskPayload(tasks, boundId, archived) {
  return JSON.stringify({
    tasks: tasks.map((t) => ({
      id: t.id,
      title: t.title,
      steps: (t.steps || []).map((s) => ({ content: stepContent(s), status: stepStatus(s) })),
      files: (t.files || []).map((f) => ({ path: f, line: undefined })),
      lastActiveAt: t.lastActiveAt,
      updatedAt: t.updatedAt,
      archived: t.archived || false,
      insights: (t.insights || []).filter((i) => !i.archived).map((i) => ({ id: i.id, kind: i.kind || 'lesson', title: i.title || '', draft: i.draft === true })),
    })),
    boundId: boundId || null,
    archived,
  })
}

/**
 * 生成 /tasks 类快照的完整输出文本（人类可读总览 + JSON 载荷）。
 * 任务动作命令复用同一函数，面板只需解析尾部 JSON 即可刷新。
 */
export function renderTaskSnapshot(config, cwd, sid) {
  const root = projectRootFor(cwd)
  if (!root) return { kind: 'error', text: NO_PROJECT_ROOT_NOTE }
  const store = new ProjectMemoryStore(memoryRootFor(root, config.memoryDir)).load()
  const tasks = store.getTasks()
  const active = tasks.filter((t) => !t.archived)
  const archived = tasks.length - active.length
  const boundId = sid ? store.getBoundTaskId(sid) : null
  const bound = boundId ? tasks.find((t) => t.id === boundId) : null

  if (!active.length) {
    const payload = buildTaskPayload([], boundId, archived)
    const note = `项目 ${root}\n任务记录: 0 套${archived ? `（归档 ${archived}）` : ''}。让模型开始干活并维护 todo 清单后会自动建档。`
    return { kind: 'success', text: fencedJson(note, payload) }
  }
  const lines = [`项目 ${root}`, `任务: ${active.length} 套${archived ? `（归档 ${archived}）` : ''}`, '']
  for (const t of active) {
    const { done, total } = stepProgress(t)
    const progress = total ? `${done}/${total}` : '无步骤'
    const inProgress = (t.steps || []).find((s) => stepStatus(s) === 'in_progress')
    const step = inProgress ? ` · 当前: ${stepContent(inProgress)}` : ''
    const marker = bound && bound.id === t.id ? '（本会话绑定）' : ''
    const files = (t.files || []).slice(0, 8)
    const fileLine = files.length ? `\n  文件: ${files.join(', ')}${t.files.length > 8 ? ' …' : ''}` : ''
    lines.push(`● ${t.title}${marker}  步骤 ${progress}${step} · ${timeAgo(t.lastActiveAt || t.updatedAt)}${fileLine}`)
  }
  lines.push('', '续接/改名/归档：直接告诉模型（list_tasks / select_task / archive_task）。')
  const humanText = lines.join('\n')
  const payload = buildTaskPayload(active, boundId, archived)
  return { kind: 'success', text: fencedJson(humanText, payload) }
}

export function tasksCommandDefinition(config, ctx) {
  return {
    name: 'tasks',
    description: '查看本项目的任务清单（几套任务、进度、涉及文件、当前绑定）',
    handler: (invocation) => {
      try {
        const { cwd, sid } = invocationContext(invocation)
        return renderTaskSnapshot(config, cwd, sid)
      } catch (err) {
        return { kind: 'error', text: `[tasks] ${err?.message || err}` }
      }
    },
  }
}
