/**
 * Task Panel — dsh web `shell.overlay` 浮动任务面板。
 * Container 组件：负责数据获取、命令桥接、状态协调
 * Presentational 组件在 TaskComponents.tsx
 */
import { Component, useEffect, useRef, useState, type ReactNode } from 'react'
import { Button } from '@deepseek-ai/dsh-client-ui-primitives'
// 图标走兼容层：0.1.5 用 IconXxx14/16，0.1.7+ 改成 IconXxxRegular + size prop
import {
  IconChevronDownOutline14,
  IconCloseOutline16,
  IconFolderOpenOutline16,
  IconQuestionOutline14,
} from './icons.ts'
import { createTranslate, zh, en } from './locales.ts'
import { useTaskData, useTaskDataActions, taskDataStore, parseTaskPayloadText, type TaskStep } from './task-data-store.ts'
import { useTaskUI, useTaskUIActions, PANEL_VIEWS } from './task-ui-store.ts'
import { MiniBar, TaskCard } from './TaskComponents.tsx'
import { MemoryView, type InsightScope } from './MemoryView.tsx'
import { pickSessionId } from './session-id.js'
import css from './TaskPanel.module.css'

const NS = 'dsh-project-memory'

const STATUS_CYCLE = ['pending', 'in_progress', 'completed'] as const
// 视图列表的唯一事实来源在 UI store（`/` 菜单那三行也读它）；这里不再抄一份。
const VIEW_CYCLE = PANEL_VIEWS

function getT(ctx: any) {
  const locale = ctx?.locale?.getSnapshot?.()?.active === 'zh' ? zh : en
  return createTranslate(locale)
}

function useSessionId(ctx: any): string | null {
  const [, force] = useState(0)
  useEffect(() => {
    const list = ctx?.sessions?.list
    if (!list || typeof list.subscribe !== 'function') return
    return list.subscribe(() => force((n) => n + 1))
  }, [ctx])
  // 快照结构在 dsh 0.1.7 变过（current/items → ids/byId）：解析与兼容都在 session-id.js，
  // 那里有单测；这里只负责订阅与取值。
  return pickSessionId(ctx?.sessions?.list?.getSnapshot?.())
}

class PanelErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  componentDidCatch(error: unknown) {
    console.warn('[dsh-project-memory] task panel render crashed:', error)
  }
  render() {
    if (!this.state.failed) return this.props.children
    return (
      <button className={css.boundaryFallback} onClick={() => this.setState({ failed: false })} title="重新渲染任务面板">
        任务面板（点击重试）
      </button>
    )
  }
}

export function TaskPanelEntry({ ctx }: { ctx: any }) {
  return (
    <PanelErrorBoundary>
      <TaskPanelView ctx={ctx} />
    </PanelErrorBoundary>
  )
}

function TaskPanelView({ ctx }: { ctx: any }) {
  const t = getT(ctx)
  const data = useTaskData()
  const ui = useTaskUI()
  const sessionId = useSessionId(ctx)
  const [syncing, setSyncing] = useState(false)
  const [syncedAt, setSyncedAt] = useState(0)
  const [syncError, setSyncError] = useState<string | null>(null)
  // 提示信息开关落在 UI store（持久化）：关掉后面板内所有悬停 title 气泡都不再弹出。
  const showHints = ui.showHints
  const dataActions = useTaskDataActions()
  const uiActions = useTaskUIActions()
  // 视图页同样落在 UI store：`/` 菜单的三行是"打开某一页"，它们必须能从这个组件外面切页。
  const view = ui.view
  const cycleView = () => {
    const i = VIEW_CYCLE.indexOf(view)
    uiActions.setView(VIEW_CYCLE[(i + 1) % VIEW_CYCLE.length])
  }
  const viewTitle =
    view === 'task' ? t('panel.title')
      : view === 'global' ? t('view.global')
        : t('view.project')

  const tasks = Array.isArray(data.tasks) ? data.tasks : []
  const activeTasks = tasks.filter((task) => !task.archived)
  const boundTask = data.boundTaskId ? tasks.find((task) => task.id === data.boundTaskId) ?? null : null

  const applyPayload = (text?: string): boolean => {
    const parsed = parseTaskPayloadText(text)
    if (!parsed) return false
    dataActions.setTasks({ tasks: parsed.tasks, boundTaskId: parsed.boundId, archivedCount: parsed.archived })
    setSyncedAt(Date.now())
    setSyncError(null)
    return true
  }

  const runLine = async (line: string): Promise<boolean> => {
    const commands = ctx?.remote?.commands
    if (!sessionId || !commands || typeof commands.execute !== 'function') {
      setSyncError('no session / commands service')
      return false
    }
    let response: any
    try {
      response = await commands.execute(sessionId, line, [])
    } catch (err) {
      setSyncError(String((err as { message?: unknown } | null | undefined)?.message ?? err))
      return false
    }
    const envelope = response as { ok?: boolean; value?: any } | null | undefined
    const execution = envelope && typeof envelope === 'object' && 'value' in envelope ? envelope.value : envelope
    const result = execution?.result ?? execution
    if (result?.kind === 'error') {
      setSyncError(result.text ?? 'command error')
      return false
    }
    return applyPayload(result?.text)
  }

  const refresh = async (): Promise<void> => {
    if (syncing) return
    setSyncing(true)
    try {
      const prevBoundId = data.boundTaskId
      await runLine('/tasks')
      const newBoundId = taskDataStore.getSnapshot().boundTaskId
      if (newBoundId && newBoundId !== prevBoundId) {
        await runLine(`/tasks switch ${newBoundId}`)
      }
    } finally {
      setSyncing(false)
    }
  }

  const handleAction = async (verb: 'switch' | 'archive', taskId: string): Promise<void> => {
    if (syncing) return
    setSyncing(true)
    try {
      await runLine(`/tasks ${verb} ${taskId}`)
    } finally {
      setSyncing(false)
    }
  }

  // v0.5：任务卡内联记忆动作（confirm/promote/delete 于 /insight task 层），随后刷新任务数据
  const handleInsightTask = async (action: 'confirm' | 'promote' | 'delete', id: string): Promise<void> => {
    if (syncing) return
    setSyncing(true)
    try {
      await runLine(`/tasks insight ${action} task ${id}`)
      await refresh()
    } finally {
      setSyncing(false)
    }
  }

  const pushSteps = (taskId: string, steps: TaskStep[]): void => {
    void runLine(`/tasks todos ${JSON.stringify(steps.map((s) => ({ content: s.content, status: s.status })))}`)
  }

  const cycleStatus = (taskId: string, index: number) => {
    const task = data.tasks.find((tt) => tt.id === taskId)
    if (!task) return
    const steps = task.steps || []
    const next = steps.map((s, i) => {
      if (i !== index) return s
      const cur = STATUS_CYCLE.indexOf(s.status)
      return { ...s, status: STATUS_CYCLE[(cur + 1) % STATUS_CYCLE.length] }
    })
    pushSteps(taskId, next)
  }

  const commitStepText = (taskId: string, index: number, value: string) => {
    const task = data.tasks.find((tt) => tt.id === taskId)
    const trimmed = value.trim()
    if (!task) return
    const same = (task.steps || [])[index]?.content === trimmed
    if (same || !trimmed) return
    const next = (task.steps || []).map((s, i) => (i === index ? { ...s, content: trimmed } : s))
    pushSteps(taskId, next)
  }

  const reorderSteps = (taskId: string, fromIndex: number, toIndex: number) => {
    if (fromIndex === toIndex) return
    const task = data.tasks.find((tt) => tt.id === taskId)
    if (!task) return
    const steps = [...(task.steps || [])]
    const [moved] = steps.splice(fromIndex, 1)
    const targetIndex = toIndex > fromIndex ? toIndex - 1 : toIndex
    steps.splice(targetIndex, 0, moved)
    pushSteps(taskId, steps)
  }

  const commitTitle = (taskId: string, value: string) => {
    const task = data.tasks.find((tt) => tt.id === taskId)
    const trimmed = value.trim()
    if (!task) return
    const same = task.title === trimmed
    if (same || !trimmed) return
    void runLine(`/tasks rename ${taskId} ${JSON.stringify(trimmed)}`)
  }

  const expand = () => {
    uiActions.open()
    if (Date.now() - Math.max(data.lastUpdate, syncedAt) > 30_000) {
      void refresh()
    }
  }

  const THEMES = ['native', 'glass', 'brutal', 'mono'] as const
  const style = (THEMES as readonly string[]).includes(ui.theme) ? ui.theme : 'native'
  const styleLabel = t(`style.${style}` as keyof typeof zh)
  const cycleTheme = () => {
    const i = THEMES.indexOf(style as (typeof THEMES)[number])
    uiActions.setTheme(THEMES[(i + 1) % THEMES.length])
  }

  const panelRef = useRef<HTMLDivElement>(null)
  const drag = useRef<{ dx: number; dy: number } | null>(null)

  const handleDragStart = (e: React.MouseEvent) => {
    if (e.target !== e.currentTarget) return
    const rect = panelRef.current?.getBoundingClientRect()
    if (!rect) return
    drag.current = { dx: e.clientX - rect.left, dy: e.clientY - rect.top }
    const onMove = (ev: MouseEvent) => {
      if (!drag.current) return
      const width = panelRef.current?.offsetWidth ?? 380
      const height = panelRef.current?.offsetHeight ?? 480
      const x = Math.max(8, Math.min(window.innerWidth - width - 8, ev.clientX - drag.current.dx))
      const y = Math.max(8, Math.min(window.innerHeight - 64, ev.clientY - drag.current.dy))
      uiActions.setPanelPosition({ x, y })
    }
    const onUp = () => {
      drag.current = null
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
  }

  // 会话切换时仅同步数据，不自动打开面板
  useEffect(() => {
    if (!sessionId) return
    // 仅当面板已打开时才自动刷新
    if (!ui.closed) {
      void refresh()
    }
  }, [sessionId])

  // 监听模型工具请求打开面板
  useEffect(() => {
    const ctxWithEvents = ctx
    const handler = () => {
      uiActions.open()
      if (Date.now() - Math.max(data.lastUpdate, syncedAt) > 30_000) {
        void refresh()
      }
    }
    ctxWithEvents?.events?.on?.('dsh:task-panel:show', handler)
    return () => {
      ctxWithEvents?.events?.off?.('dsh:task-panel:show', handler)
    }
  }, [ctx, uiActions, data.lastUpdate, syncedAt, refresh])

  // 彻底隐藏：不渲染任何东西
  if (ui.closed) {
    return null
  }

  // 折叠态：迷你条
  if (ui.minimized) {
    const label = boundTask
      ? `${t('minibar.current')}: ${boundTask.title}`
      : activeTasks.length > 0
        ? `${t('minibar.current')}: ${activeTasks.length} ${t('minibar.tasks')}`
        : t('minibar.no-task')
    return (
      <MiniBar
        label={label}
        hint={t('minibar.click-expand')}
        showHints={showHints}
        position={ui.panelPosition}
        theme={style}
        onMove={uiActions.setPanelPosition}
        open={expand}
      />
    )
  }

  const doneCount = activeTasks.filter((task) => {
    const steps = task.steps || []
    return steps.length > 0 && steps.every((s) => s.status === 'completed')
  }).length

  return (
    <div
      className={css.panel}
      ref={panelRef}
      style={{ left: ui.panelPosition.x, top: ui.panelPosition.y }}
      data-theme={style === 'native' ? undefined : style}
    >
      <div className={css.dragHandle} onMouseDown={handleDragStart} title={showHints ? t('task.drag') : undefined}>
        <div className={css.handleGrip} />
      </div>
      <header className={css.header}>
        <div className={css.headerLeft}>
          <Button
            type="button"
            className={css.headerIconBtn}
            onClick={cycleTheme}
            title={showHints ? styleLabel : undefined}
            aria-label={styleLabel}
          >
            <IconFolderOpenOutline16 className={css.headerIcon} />
          </Button>
          <h2 className={css.headerTitle}>{viewTitle}</h2>
        </div>
        <div className={css.headerRight}>
          <Button
            variant="ghost"
            size="sm"
            onClick={cycleView}
            aria-label={t('view.cycle')}
            title={showHints ? `${t('view.cycle')}（${view} → ${VIEW_CYCLE[(VIEW_CYCLE.indexOf(view) + 1) % VIEW_CYCLE.length]}）` : undefined}
          >
            {/* lucide notebook-tabs（视图循环图标） */}
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M2 6h4" />
              <path d="M2 10h4" />
              <path d="M2 14h4" />
              <path d="M2 18h4" />
              <rect width="16" height="20" x="4" y="2" rx="2" />
              <path d="M15 2v20" />
              <path d="M15 7h5" />
              <path d="M15 12h5" />
              <path d="M15 17h5" />
            </svg>
          </Button>
          {view === 'task' && (
            <span className={css.counts}>
              {activeTasks.length > 0
                ? `${t('panel.active')} ${activeTasks.length} · ${doneCount}/${activeTasks.length}`
                : ''}
            </span>
          )}
          <Button
            variant="ghost"
            size="sm"
            className={showHints ? undefined : css.hintsOff}
            onClick={() => uiActions.toggleHints()}
            aria-pressed={!showHints}
            aria-label={showHints ? t('panel.hints-off') : t('panel.hints-on')}
            title={showHints ? t('panel.hints-off') : t('panel.hints-on')}
          >
            <IconQuestionOutline14 size={16} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => uiActions.minimize()}
            aria-label={t('panel.minimize')}
            title={showHints ? t('panel.minimize') : undefined}
          >
            <IconChevronDownOutline14 />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => uiActions.close()}
            aria-label={t('panel.close')}
            title={showHints ? t('panel.close') : undefined}
          >
            <IconCloseOutline16 />
          </Button>
        </div>
      </header>

      {!sessionId && <div className={css.notice}>{t('panel.no-session')}</div>}
      {syncError && <div className={css.notice}>{t('panel.sync-failed')}: {syncError}</div>}

      {view !== 'task' ? (
        <MemoryView ctx={ctx} sessionId={sessionId} scope={view as InsightScope} boundTaskId={data.boundTaskId} showHints={showHints} t={t} />
      ) : activeTasks.length === 0 ? (
        <div className={css.emptyState}>
          <p className={css.emptyTitle}>{t('panel.empty')}</p>
          <p className={css.emptyDesc}>{t('panel.empty-desc')}</p>
          {syncing && <p className={css.syncHint}>{t('panel.syncing')}</p>}
        </div>
      ) : (
        <div className={css.taskList}>
          {activeTasks.map((task) => {
            const steps = task.steps || []
            const expanded = ui.expandedTaskIds.includes(task.id)
            const isBound = data.boundTaskId === task.id
            return (
              <TaskCard
                key={task.id}
                task={task}
                isBound={isBound}
                expanded={expanded}
                onToggleExpand={() => uiActions.toggleTaskExpanded(task.id)}
                onSwitch={() => handleAction('switch', task.id)}
                onUnbind={() => runLine('/tasks unbind')}
                onArchive={() => handleAction('archive', task.id)}
                onRename={(value) => commitTitle(task.id, value)}
                onEditStep={(index, value) => commitStepText(task.id, index, value)}
                onCycleStatus={(index) => cycleStatus(task.id, index)}
                onReorderSteps={(from, to) => reorderSteps(task.id, from, to)}
                onInsightAction={(action, id) => void handleInsightTask(action, id)}
                showHints={showHints}
                syncing={syncing}
                t={t}
              />
            )
          })}
          {syncing && <div className={css.syncHint}>{t('panel.syncing')}</div>}
        </div>
      )}
    </div>
  )
}