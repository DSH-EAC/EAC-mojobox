import { defineTool } from '@deepseek-ai/dsh-tools'
import { assertIndexRoot, memoryRootFor, resolveSafeIndexRoot } from '../util/fs.js'
import { ProjectMemoryStore } from '../store.js'

export function rememberTool(config) {
  return defineTool({
    name: 'remember',
    description:
      'Save an experience note (problem -> solution) into project memory, e.g. a bug you just fixed. ' +
      'Retrieved later only when query_memory matches the problem, never auto-injected. ' +
      'A note for a similar problem is superseded instead of duplicated. ' +
      'This writes the standalone experience file: for lessons / decisions / procedures prefer save_lesson ' +
      '(the tiered insight store) — query_memory searches both.',
    parameters: {
      problem: {
        type: 'string',
        required: true,
        description: 'The problem/situation, e.g. "pdfjs OPS import fails on Node 24".',
      },
      solution: {
        type: 'string',
        required: true,
        description: 'The concrete fix or decision, e.g. "import OPS from pdfjs-dist/legacy/build/pdf.mjs".',
      },
      root: {
        type: 'string',
        description: 'Project root of the memory store. Defaults to the current working directory.',
      },
      source_file: {
        type: 'string',
        description: 'Optional file the problem is about, for traceability.',
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      const root = resolveSafeIndexRoot(exec, args.root, config)
      // 写盘前校验根：否则一个拼错的 root 会被 mkdir 成字面量目录（连同 .dsh-project-memory）。
      assertIndexRoot(root, args.root || root)
      const memoryDir = memoryRootFor(root, config.memoryDir)
      const store = new ProjectMemoryStore(memoryDir).load()
      return store.commit((s) => {
        const result = s.addExperience({
          problem: args.problem,
          solution: args.solution,
          sourceFile: args.source_file,
        })
        return result.superseded
          ? `Updated existing experience note (${result.id}).`
          : `Saved experience note (${result.id}).`
      })
    },
  })
}