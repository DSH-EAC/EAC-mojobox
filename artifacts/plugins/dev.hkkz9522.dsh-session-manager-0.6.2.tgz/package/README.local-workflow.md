# AI Dev Workflow Template

核心关系：
```text
AGENTS.md = Agent 统一入口
.ai/      = 工作流和项目知识的唯一事实来源
.codex/   = 由脚本从 .ai/skills 生成的 Codex Skill 转发层（不要手改）
```

## 新项目第一次使用
复制到项目根目录后，先让 AI 初始化：
- `.ai/architecture.md`
- `.ai/safety.md`
- `.ai/project-commands.md`

推荐启动指令：
```text
先不要开始开发。
请读取 AGENTS.md 和当前项目，帮我初始化 .ai 下的项目知识和验证规则。
重点完善：
- .ai/architecture.md
- .ai/safety.md
- .ai/project-commands.md
只写能够从当前项目确认的事实；不确定的地方标记“待确认”，不要猜。
填写完成后把每个文件头部的「最后核对日期」改成今天。
暂时不要修改业务代码。
```


## 常用 Skill
- requirements-grill
- regression-fix
- code-review
- high-risk-review
- release-check

## 维护 Skill
只改 `.ai/skills/<name>/SKILL.md`，然后重新生成转发层（PowerShell 7）：
```powershell
.\sync-codex-skills.ps1          # 生成 / 更新 .codex/skills，删除已不存在的 skill
.\sync-codex-skills.ps1 -Check   # 只比对不写入，有漂移则报错
```
生成文件带日期标记；内容未变时不会重写，可重复运行。

## 本地忽略（仅 Git 仓库需要）
PowerShell 7，在主仓库根目录运行：
```powershell
.\setup-local-workflow.ps1
```
脚本会校验 `.git` 是真实的仓库根目录（不是 worktree / submodule 的 `.git` 文件），写入 `.git/info/exclude`，然后自动执行一次 `sync-codex-skills.ps1`。非 Git 仓库不需要运行；运行了会直接报错退出，不会写任何东西。

然后运行 `git status` 确认本地 AI 文件未进入待提交列表。
